package com.training.workers;

public class CityNamePrintingThread extends Thread {
	public void run() {

		Thread thread = Thread.currentThread();
		String threadName = thread.getName();

		for (int i = 1; i <= 10; i++) {
			System.out.println(threadName + " : " + "Cochin");
			try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {

				e.printStackTrace();
			}
		}
	}

}
