package com.training.ui;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;

public class Main6 {

	public static void main(String[] args) {
		OutputStream os = null;
		Writer writer = null;

		try {
			os = new FileOutputStream("Welcome1.txt");
			writer = new OutputStreamWriter(os);
		} catch (FileNotFoundException e) {
			System.err.println("Some problem in opening the file");
			System.exit(0);
		}

		String str = "Java 8 has awesome features...\nFunctional Interfaces...\n Lambda...\nStream API";
		try {
			writer.write(str);
		} catch (IOException e) {
			System.err.println("Some problem in writing the file");
			System.exit(0);
		}

		try {
			writer.flush();
			writer.close();
			os.close();
		} catch (IOException e) {
			System.err.println("Some problem in closing the file");
			System.exit(0);
		}

	}

}
