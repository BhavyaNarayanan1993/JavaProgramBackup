package com.training.ui;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;

import com.training.model.Employee;

public class Main10 {

	public static void main(String[] args) throws IOException {
		InputStream is=System.in;
		Reader reader=new InputStreamReader(is);
		BufferedReader br=new BufferedReader(reader);
		
		int id;
		String name;
		String gender;
		String city;
		double basic;
		
		System.out.println("Enter the Id:");
		String str=br.readLine();
		id=Integer.parseInt(str);
		System.out.println(id);
		
		System.out.println("Enter your Name:");
		name=br.readLine();
		System.out.println(name);
		
		System.out.println("Enter your Gender:");
		gender=br.readLine();
		System.out.println(gender);
		
		System.out.println("Enter your City:");
		city=br.readLine();
		System.out.println(city);
		
		System.out.println("Enter your Basic Salary:");
		str=br.readLine();
		basic=Double.parseDouble(str);
		System.out.println(basic);
		
		Employee e=new Employee();
		e.setId(id);
		e.setName(name);
		e.setGender(gender);
		e.setCityName(city);
		e.setBasic(basic);
		
		System.out.println("Net Salary: "+e.getNetSalary());
		System.out.println(e.toString());
		
	}

}
