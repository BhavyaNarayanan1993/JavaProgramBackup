package com.training.ui;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;

public class Main5 {

	public static void main(String[] args) {
		InputStream is=null;
		Reader reader=null;		//high level stream object
		
		try {
			is= new FileInputStream("Hello.txt");
		} catch (FileNotFoundException e) {
			System.err.println("Some Problem while opening the file");
			System.exit(0);
		}
		//here directly char is read instead of ascii value
		reader=new InputStreamReader(is); 
		try {
			int sizeOfFile=is.available();
			char[] arr=new char[sizeOfFile];
			reader.read(arr);
			String str=new String(arr);
			System.out.println(str);
		} catch (IOException e) {
			System.out.println("Problem while reading ");
			System.exit(0);
		}
		try {
			reader.close();
			is.close();
		} catch (IOException e) {
			System.out.println("Problem while closing the file ");
			System.exit(0);
		}
		

	}

}
