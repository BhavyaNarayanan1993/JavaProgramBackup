package com.training.ui;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

public class Main2 {

	public static void main(String[] args) throws IOException {
		OutputStream os;
		os=new FileOutputStream("Welcome.txt");
		
		String str="I am fine...\n Hope you are doing good \n Please visit us";
		for(int i=0;i<str.length();i++) {
			char ch=str.charAt(i);
			os.write(ch);
		}
		os.flush();// to clear the internal memory area
		os.close();
	

	}

}
