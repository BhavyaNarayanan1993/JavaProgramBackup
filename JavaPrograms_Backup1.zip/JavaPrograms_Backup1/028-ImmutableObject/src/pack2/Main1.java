package pack2;

public class Main1 {

	public static void main(String[] args) {
		final int a=100;

		System.out.println(a);
		System.out.println(a+100);
		

	}

}
