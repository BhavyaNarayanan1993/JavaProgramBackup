package pack2;

import pack1.Circle;

public class Main3 {

	public static void main(String[] args) {
		Circle cir1=new Circle(10);
		System.out.println(cir1);
		
		Circle cir2=cir1.enLarge(100);
		System.out.println(cir2);
		
		Circle cir3=new Circle(20);
		System.out.println(cir3);
		
		Circle cir4=cir3.enLarge(400);
		System.out.println(cir4);

	}

}
