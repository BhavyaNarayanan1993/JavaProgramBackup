package com.training.model;

import java.util.concurrent.atomic.AtomicInteger;

public class SafeIncrement {
	private AtomicInteger counter=new AtomicInteger();
	
	public int getValue() {
		return counter.get();
	}
	
	public void increment() {
		counter.incrementAndGet();  // counter++
	}

}
