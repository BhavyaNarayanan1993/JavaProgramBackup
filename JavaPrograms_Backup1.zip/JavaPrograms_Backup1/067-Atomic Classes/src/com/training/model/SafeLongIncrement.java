package com.training.model;

import java.util.concurrent.atomic.AtomicLong;

public class SafeLongIncrement {
	//AtomicLong object
	private AtomicLong counter=new AtomicLong();
	
	public long getValue() {
		return counter.get();
		
	}
	
	public void increment() {
		counter.incrementAndGet();
	}

}
