package com.training.ui;

import com.training.model.SafeLongIncrement;

public class Main3 {

	public static void main(String[] args) {
		// create an object of SafeLongIncrement object
		//increment
		//print the value
		
		SafeLongIncrement sli=new SafeLongIncrement();
		sli.increment();
		System.out.println(sli.getValue());

	}

}
