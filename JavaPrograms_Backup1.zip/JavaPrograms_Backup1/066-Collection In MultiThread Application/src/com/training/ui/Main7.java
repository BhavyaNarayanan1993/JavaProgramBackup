package com.training.ui;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

public class Main7 {

	public static void main(String[] args) {
		List<Integer> ilist=new CopyOnWriteArrayList<>();
		
		ilist.add(10);
		ilist.add(20);
		ilist.add(30);
		
		Iterator<Integer> it=ilist.iterator();		//fail safe iterator
		while(it.hasNext()) {
			Integer n=it.next();
			System.out.println(n);
			ilist.add(Integer.valueOf(1000));
			
		}
		System.out.println();
		System.out.println("-----------------------------------------------------------------");
		it= ilist.iterator();		
		while(it.hasNext()) {
			Integer n=it.next();
			System.out.println(n);
		}

	}

}
