package com.training.ui;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Main2 {

	public static void main(String[] args) throws InterruptedException {
		
			List<Double> dlist=Collections.synchronizedList(new  ArrayList<>());	//initialize
			
			//Runnable to add numbers from 1 to 100 to dlist
			//create thread and start
			
			Runnable runnable1=()->{
				for(int i=1;i<=100;i++) {
					dlist.add((double)i);
				}
			System.out.println(dlist);
			};
		
			//Runnable to add numbers from 101 to 300 to dlist
			//create thread and start
			
			Runnable runnable2=()->{
				for(int i=101;i<=300;i++) {
					dlist.add((double)i);
				}
				System.out.println(dlist);
			};
			Thread t1=new Thread(runnable1,"T1");
			t1.start();
			
			Thread t2=new Thread(runnable2,"T2");
			t2.start();
			
			t1.join();
			t2.join();
			//Print the size of dlist
			System.out.println(dlist.size());

	}

}
