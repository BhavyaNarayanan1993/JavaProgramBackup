package com.training.ui;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class Main4 {

	public static void main(String[] args) throws InterruptedException {
		List<Integer> ilist = new ArrayList<>();

		Lock lock = new ReentrantLock();

		Runnable runnable1 = () -> {
			lock.lock();

			for (int i = 1; i <= 10; i++)
				ilist.add(i);

			lock.unlock();
		};

		Runnable runnable2 = () -> {
			lock.lock();
			for (int i = 11; i <= 20; i++)
				ilist.add(i);
			lock.unlock();
		};

		Thread t1 = new Thread(runnable1, "T1");
		Thread t2 = new Thread(runnable2, "T2");
		t1.start();
		t2.start();

		t1.join();
		t2.join();

		System.out.println(ilist);
		System.out.println(ilist.size());

	}

}
