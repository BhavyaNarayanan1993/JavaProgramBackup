package pack2;

import pack1.Employee;

public class Main1 {

	public static void main(String[] args) {
		Employee emp=new Employee(1000.00);
		System.out.println(emp.computeNetSalary());	//compile time polymorphism
		System.out.println(emp.computeNetSalary(10));
		System.out.println(emp.computeNetSalary(10, 800));

	}

}
