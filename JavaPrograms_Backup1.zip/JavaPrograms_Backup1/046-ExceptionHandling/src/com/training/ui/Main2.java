package com.training.ui;

public class Main2 {

	private static void printLength(String str) {
		try {
		System.out.println(str.length());
		}
		catch(NullPointerException e)
		{
			//e.printStackTrace();
			System.out.println(e);
		}
	}
	public static void main(String[] args) {
		String str1="Welcome";
		String str2=null;
		String str3="UST";
		
		printLength(str1);
		printLength(str2);
		printLength(str3);


	}

}
