package com.training.ui;

import com.training.model.InvalidCustomerNameException;
import com.training.model.InvalidLoanAmountException;
import com.training.model.InvalidLoanIdException;
import com.training.model.InvalidTenureException;
import com.training.model.Loan;

public class Main5 {
	public static void main(String[] args) throws Exception {
		//Loan loan=new Loan(-10,"Manu",-899,-100);
		
		try {
			Loan loan=new Loan(-10,"Manu",-899,-100);
		}catch (Exception e) {
			e.printStackTrace();
		}
		/*
		 * try { loan.setLoanId(-10); } catch (InvalidLoanIdException e) {
		 * System.out.println(e); e.printStackTrace(); }
		 * 
		 * try { loan.setCustomerName("Manu");; } catch (InvalidCustomerNameException e)
		 * { System.out.println(e); e.printStackTrace(); }
		 * 
		 * try { loan.setLoanAmount(-500); } catch (InvalidLoanAmountException e) {
		 * System.out.println(e); e.printStackTrace(); }
		 * 
		 * try { loan.setTenure(-88); } catch (InvalidTenureException e) {
		 * System.out.println(e); e.printStackTrace(); }
		 */
		
	}

}
