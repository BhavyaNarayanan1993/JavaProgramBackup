package com.training.model;

public class InvalidCustomerNameException extends RuntimeException{

	public InvalidCustomerNameException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public InvalidCustomerNameException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public InvalidCustomerNameException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public InvalidCustomerNameException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public InvalidCustomerNameException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
