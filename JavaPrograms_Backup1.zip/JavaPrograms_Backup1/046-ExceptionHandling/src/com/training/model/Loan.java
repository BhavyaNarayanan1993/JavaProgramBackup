package com.training.model;

public class Loan {
		
		private int loanId;
		private String customerName;
		private double loanAmount;
		private int tenure;
		
		public Loan(int loanId, String customerName, double loanAmount, int tenure) throws InvalidLoanAmountException, InvalidTenureException {
			super();
			setLoanId(loanId);
			setCustomerName(customerName);
			setLoanAmount(loanAmount);
			setTenure(tenure);
		}
		
		public Loan() {
			super();
		}

		public int getLoanId() {
			return loanId;
		}
		public void setLoanId(int loanId) {
			if(loanId<0) {
				InvalidLoanIdException e= new InvalidLoanIdException("Invalid Loan Id:"+loanId);
				throw e;
			}
			this.loanId = loanId;
		}
		public String getCustomerName() {
			return customerName;
		}
		public void setCustomerName(String customerName) {
			if(customerName==null || customerName.length()==0) {
				InvalidCustomerNameException e=new InvalidCustomerNameException("Invalid Customer Name:"+customerName);
				throw e;
			}
			this.customerName = customerName;
		}
		public double getLoanAmount() {
			return loanAmount;
		}
		public void setLoanAmount(double loanAmount) throws InvalidLoanAmountException {
			if(loanAmount<0) {
				InvalidLoanAmountException e= new InvalidLoanAmountException("Invalid Loan Amount:"+loanAmount);
				throw e;
			}
			this.loanAmount = loanAmount;
		}
		public int getTenure() {
			return tenure;
		}
		public void setTenure(int tenure) throws InvalidTenureException {
			if(tenure<0) {
				InvalidTenureException e= new InvalidTenureException("Invalid Tenure:"+tenure);
				throw e;
			}
			
			this.tenure = tenure;
		}
		
		
}
