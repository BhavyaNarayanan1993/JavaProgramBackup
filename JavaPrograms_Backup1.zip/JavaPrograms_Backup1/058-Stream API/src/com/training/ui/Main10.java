package com.training.ui;

import com.training.model.Course;

public class Main10 {

	public static void main(String[] args) {
		Course course=new Course("Diploma in Web");
		course.addCourseItem("HTML",40,8500.00);
		course.addCourseItem("CSS",20,500.00);
		course.addCourseItem("jQuery",30,3500.00);
		course.addCourseItem("Knockout js",15,1500.00);
		course.addCourseItem("Angular",50,7500.00);
		
		System.out.println(course.getLongestDurationCourseItem());
		System.out.println(course.getShortestDurationCourseItem());
		
		System.out.println(course.getHighestPriceCourseItem());
		System.out.println(course.getLowestPriceCourseItem());
	}

}
