package com.training.ui;

import java.util.LinkedList;
import java.util.List;

import com.training.model.BillItem;

public class Main15 {

	public static void main(String[] args) {
		List<BillItem> billItem = new LinkedList();
		
		billItem.add(new BillItem("Redmi", 10, 10000.00));
		billItem.add(new BillItem("Oppo", 15, 15000.00));
		billItem.add(new BillItem("Lenovo", 12, 12000.00));
		billItem.add(new BillItem("Redmi", 20, 40000.00));
		billItem.add(new BillItem("OnePlus", 25, 50000.00));
		billItem.add(new BillItem("VIVO", 50, 25000.00));
		
		double result=billItem
				.stream()
				.map(e->e.getItemValue())
				.reduce(0.0, (b1,b2)->b1+b2);
		System.out.println(result);
		
		

	}

}
