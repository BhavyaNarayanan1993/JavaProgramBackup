package com.training.ui;

import java.util.LinkedList;
import java.util.List;

import com.training.model.Circle;

public class Main12 {

	public static void main(String[] args) {
		List<Circle> circles=new LinkedList<>();
		circles.add(new Circle(5));
		circles.add(new Circle(7));
		circles.add(new Circle(12));
		circles.add(new Circle(10));
		circles.add(new Circle(20));
		
		boolean result1=circles
				.stream()
				.anyMatch(r->r.getRadius()>10);
		System.out.println(result1);
		
		boolean result2=circles
				.stream()
				.allMatch(r->r.getRadius()>2);
		System.out.println(result2);
		
		boolean result3=circles
				.stream()
				.noneMatch(r->r.getRadius()==0);
		System.out.println(result3);
		
		
		
	}

}
