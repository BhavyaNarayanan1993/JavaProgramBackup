package com.training.ui;

import java.util.LinkedList;
import java.util.List;
import java.util.Optional;

import com.training.model.Person;
import com.training.model.comparators.PersonNameComparator;

public class Main9 {

	public static void main(String[] args) {

		List<Person> allPersons=new LinkedList<>();
		allPersons.add(new Person("Ram", 23));
		allPersons.add(new Person("Dinesh", 33));
		allPersons.add(new Person("Manu", 40));
		allPersons.add(new Person("Seema", 34));
		allPersons.add(new Person("Reena", 24));
		
		Optional<Person> optionalResult=allPersons
			.stream()
			.min(new PersonNameComparator());
		
		if(optionalResult.isPresent()) {
			System.out.println(optionalResult.get());
		}else
		{
			System.out.println("Collection is Empty");
		}

		System.out.println("--------------------------------------------------");
		
		
		Optional<Person> optionalResult2= allPersons
			.stream()
			.min(
				(p1,p2)->p1.getAge()-p2.getAge()
				);
		if(optionalResult2.isPresent()) {
			System.out.println(optionalResult2.get());
		}else
		{
			System.out.println("Collection is Empty");
		}	
		
		System.out.println("--------------------------------------------------");
		
		Optional<Person> optionalResult3= allPersons
				.stream()
				.max(
					(p1,p2)->p1.getAge()-p2.getAge()
					);
		if(optionalResult3.isPresent()) {
			System.out.println(optionalResult3.get());
		}else
		{
			System.out.println("Collection is Empty");
		}	
			
		System.out.println("--------------------------------------------------");
		
		Optional<Person> optionalResult4=allPersons
				.stream()
				.max(new PersonNameComparator());
			
		if(optionalResult4.isPresent()) {
			System.out.println(optionalResult4.get());
		}else
		{
			System.out.println("Collection is Empty");
		}
	}

}
