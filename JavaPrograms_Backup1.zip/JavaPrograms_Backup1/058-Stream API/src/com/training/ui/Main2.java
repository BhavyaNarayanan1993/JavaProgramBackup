package com.training.ui;

import java.util.LinkedList;
import java.util.List;

import com.training.model.Circle;

public class Main2 {

	public static void main(String[] args) {
		List<Integer> ilist=new LinkedList<>();
		
		ilist.add(Integer.valueOf(200));
		ilist.add(Integer.valueOf(10));
		ilist.add(Integer.valueOf(150));
		ilist.add(Integer.valueOf(180));
		ilist.add(Integer.valueOf(140));
		
		ilist
			.stream()
			.sorted()
			.filter((i)->i>=100)
			.forEach((i)->System.out.println(i));
		
		List<String> cities=new LinkedList<>();
		cities.add("Pune");
		cities.add("Patna");
		cities.add("Kolkata");
		cities.add("Cochin");
		
		cities
			.stream()
			.sorted()
			.filter((c)->c.length()>=6)
			.forEach((c)->System.out.println(c));
		
		List<Circle> circles=new LinkedList<>();
		circles.add(new Circle(10));
		circles.add(new Circle(200));
		circles.add(new Circle(350));
		circles.add(new Circle(40));
		circles.add(new Circle(560));
		
		circles
			.stream()
			.sorted()
			.filter((r)->r.getRadius()>=100)
			.forEach((r)->System.out.println(r));

	}

}
