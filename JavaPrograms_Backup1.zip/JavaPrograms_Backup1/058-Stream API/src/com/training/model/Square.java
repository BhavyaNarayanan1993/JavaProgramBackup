package com.training.model;

public class Square{

	private int size;

	public Square(int size) {
		super();
		this.size = size;
	}

	public int getSize() {
		return size;
	}

	public void setSize(int size) {
		this.size = size;
	}
	
	public int getArea() {
		return this.size*this.size;
	}

	@Override
	public String toString() {
		return "\nSquare [size=" + size + ", getArea()=" + getArea() + "]";
	}

	
	
}
