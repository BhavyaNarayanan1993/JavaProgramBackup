package com.training.model.comparators;

import java.util.Comparator;

import com.training.model.BillItem;

public class BillItemQuantityComparator implements Comparator<BillItem>{

	@Override
	public int compare(BillItem item1, BillItem item2) {
		
		if(item1.getQuantity()<item2.getQuantity())
			return -1;
		if(item1.getQuantity()>item2.getQuantity())
			return 1;
		return 0;
	}

	
}
