package com.training.model.comparators;

import java.util.Comparator;

import com.training.model.Person;

public class PersonNameComparator implements Comparator<Person>{

	@Override
	public int compare(Person p1, Person p2) {
		int r = p1.getName().compareTo(p2.getName());
		return r;
	}

}
