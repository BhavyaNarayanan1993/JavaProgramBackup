package model;

public class SavingsAccount {

}
