package UI;

public class CustomerRegistrationScreen {

}
