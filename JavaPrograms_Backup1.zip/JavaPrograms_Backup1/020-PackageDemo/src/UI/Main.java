package UI;

import model.Account;
import model.CurrentAccount;
import model.Customer;
import model.SavingsAccount;
import model.deposits.FixedDeposit;
import model.deposits.RecurringDeposit;
import db.AccountDAO;
import db.CustomerDAO;
import db.DBConnectionManager;
//import model.*;
//import model.deposits.*;

public class Main {

	public static void main(String[] args) {
		MainScreen ms=new MainScreen();
		CustomerRegistrationScreen crs=new CustomerRegistrationScreen();
		
		Account account=new Account();
		Customer customer=new Customer();
		
		SavingsAccount sa=new SavingsAccount();
		CurrentAccount ca=new CurrentAccount();
		
		FixedDeposit fd=new FixedDeposit();
		RecurringDeposit rd=new RecurringDeposit();
		
		AccountDAO ad=new AccountDAO();
		CustomerDAO cust=new CustomerDAO();
		DBConnectionManager db=new DBConnectionManager();

	}

}
