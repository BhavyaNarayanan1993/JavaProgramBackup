package pack1;

public class Main4 {

	public static void main(String[] args) {
		// Long class
		
		long a=20000;
		Long lobj=Long.valueOf(a);//boxing
		
		byte v1=lobj.byteValue();
		System.out.println(v1);
		
		short v2=lobj.shortValue();
		System.out.println(v2);
		
		int v3=lobj.intValue();
		System.out.println(v3);
		
		long v4=lobj.longValue();//unboxing
		System.out.println(v4);
		
		float v5=lobj.floatValue();
		System.out.println(v5);
		
		double v6=lobj.doubleValue();
		System.out.println(v6);
		
		String str="79";
		long x=Long.parseLong(str);
		System.out.println(++x);
		
		System.out.println(Long.MIN_VALUE);
		System.out.println(Long.MAX_VALUE);

	}

}
