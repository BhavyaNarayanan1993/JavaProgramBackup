package pack1;

public class Main8 {

		public static void main(String[] args) {
			
			Double a=600.00;
			Double dobj1=a;	//auto boxing
			
			
			double b=dobj1; //auto unboxing
			
			System.out.println(dobj1);
			++dobj1;
			System.out.println(dobj1);
		}
}
