package pack1;

public class Main5 {

	public static void main(String[] args) {
		// Float class

		float a=20000.00f;
		Float fobj=Float.valueOf(a);//boxing
		
		byte v1=fobj.byteValue();
		System.out.println(v1);
		
		short v2=fobj.shortValue();
		System.out.println(v2);
		
		int v3=fobj.intValue();
		System.out.println(v3);
		
		long v4=fobj.longValue();
		System.out.println(v4);
		
		float v5=fobj.floatValue();//unboxing
		System.out.println(v5);
		
		double v6=fobj.doubleValue();
		System.out.println(v6);
		
		String str="69.0";
		float x=Float.parseFloat(str);
		System.out.println(++x);
		
		System.out.println(Float.MIN_VALUE);
		System.out.println(Float.MAX_VALUE);
	}

}
