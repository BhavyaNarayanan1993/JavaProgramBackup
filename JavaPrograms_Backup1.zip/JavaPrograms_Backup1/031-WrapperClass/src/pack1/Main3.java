package pack1;

public class Main3 {

	public static void main(String[] args) {
		// Short Class
		
		short a=200;
		Short sobj=Short.valueOf(a);//boxing
		
		byte v1=sobj.byteValue();
		System.out.println(v1);
		
		short v2=sobj.shortValue();//unboxing
		System.out.println(v2);
		
		int v3=sobj.intValue();
		System.out.println(v3);
		
		long v4=sobj.longValue();
		System.out.println(v4);
		
		float v5=sobj.floatValue();
		System.out.println(v5);
		
		double v6=sobj.doubleValue();
		System.out.println(v6);
		
		String str="89";
		short x=Short.parseShort(str);
		System.out.println(++x);
		
		System.out.println(Short.MIN_VALUE);
		System.out.println(Short.MAX_VALUE);

	}

}
