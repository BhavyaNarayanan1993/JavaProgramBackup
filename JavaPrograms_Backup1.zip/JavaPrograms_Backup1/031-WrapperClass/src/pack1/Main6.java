package pack1;

public class Main6 {

	public static void main(String[] args) {
		// Double class
		
		double a=40000.00;
		Double dobj=Double.valueOf(a);//boxing
		
		byte v1=dobj.byteValue();
		System.out.println(v1);
		
		short v2=dobj.shortValue();
		System.out.println(v2);
		
		int v3=dobj.intValue();
		System.out.println(v3);
		
		long v4=dobj.longValue();
		System.out.println(v4);
		
		float v5=dobj.floatValue();
		System.out.println(v5);
		
		double v6=dobj.doubleValue();//unboxing
		System.out.println(v6);
		
		String str="100.0";
		double x=Double.parseDouble(str);
		System.out.println(++x);
		
		System.out.println(Double.MIN_VALUE);
		System.out.println(Double.MAX_VALUE);

	}

}
