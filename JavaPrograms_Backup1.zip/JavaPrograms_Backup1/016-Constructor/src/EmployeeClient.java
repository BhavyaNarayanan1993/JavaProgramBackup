
public class EmployeeClient {

	public static void main(String[] args) {
		Employee emp=new Employee();
		emp.setId(100);
		emp.setName("Rahul");
		emp.setCityName("Bangalore");
		emp.setBasic(5000.00);
		emp.setGrade('A');
		
		System.out.println(emp.getId());
		System.out.println(emp.getName());
		System.out.println(emp.getCityName());
		System.out.println(emp.getBasic());
		System.out.println(emp.getGrade());
		
		
		Employee emp2=new Employee(200, "Manu", "Mumbai", 3000.00, 'B');
		System.out.println(emp2.getId());
		System.out.println(emp2.getName());
		System.out.println(emp2.getCityName());
		System.out.println(emp2.getBasic());
		System.out.println(emp2.getGrade());
		

	}

}
