
public class StudentClient {

	public static void main(String[] args) {

		Student stud=new Student();
		stud.setRollNumber(1);
		stud.setName("Agneya");
		stud.setMark1(79);
		stud.setMark2(66);
		stud.setGender("Female");
		
		System.out.println(stud.getRollNumber());
		System.out.println(stud.getName());
		System.out.println(stud.getMark1());
		System.out.println(stud.getMark2());
		System.out.println(stud.getGender());
		
		
		Student stud2=new Student(2, "Aryan", 55, 88, "Male");
		
		System.out.println(stud2.getRollNumber());
		System.out.println(stud2.getName());
		System.out.println(stud2.getMark1());
		System.out.println(stud2.getMark2());
		System.out.println(stud2.getGender());
	}

}
