
public class Circle {
	
		Circle(){
			//constructor method
			System.out.println("Circle object created");
		}
		
		Circle(int radius)
		{
			this.radius=radius;
			System.out.println("Circle object created with radius "+radius);
		}
		
		private int radius;
		
		void setRadius(int r) {
			if(r<0) {
				System.out.println("Invalid Radius");
				return ;
			}
			radius=r;
		}
		
		int getRadius() {
			return radius;
		}
		double getArea() {
			return 3.14*radius*radius;
		}

}
