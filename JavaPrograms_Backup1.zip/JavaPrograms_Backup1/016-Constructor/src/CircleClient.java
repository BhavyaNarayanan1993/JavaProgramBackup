
public class CircleClient {

	public static void main(String[] args) {
		Circle c1=new Circle();
		c1.setRadius(200);
		
		Circle c2=new Circle(10);
		
		new Circle(100);

	}

}
