package modifierpack1;

public class ModResearch2 {
	
	public void research2() {
		ModResearch1 mr=new ModResearch1();
		System.out.println("Inside ModResearch2 ");
		//System.out.println("ID: "+mr.id);
		System.out.println("NAME: "+mr.name);
		System.out.println("GENDER: "+mr.gender);
		System.out.println("SALARY: "+mr.salary);
		ModResearch1.test1();
	}

}
