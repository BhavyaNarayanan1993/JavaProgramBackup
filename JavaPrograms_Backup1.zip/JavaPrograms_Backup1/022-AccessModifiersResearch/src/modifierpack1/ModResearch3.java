package modifierpack1;

public class ModResearch3 extends ModResearch1 {
	
	public void research6() {
		
		System.out.println("Inside ModResearch3 ");
		//System.out.println("ID: "+id);
		System.out.println("NAME: "+name);
		System.out.println("GENDER: "+gender);
		System.out.println("SALARY: "+salary);
		
	}
	
	public void research7() {
		ModResearch1 mr=new ModResearch1();
		System.out.println("Inside ModResearch3 ");
		//System.out.println("ID: "+mr.id);
		System.out.println("NAME: "+mr.name);
		System.out.println("GENDER: "+mr.gender);
		System.out.println("SALARY: "+mr.salary);
		ModResearch1.test1();
	}

}
