package modifierpack1;

public class ModResearch1 {

				private int id=10;
				String name="Ram";
				protected String gender="MALE";
				public double salary=1000.00;
				
				public void research1() {
					System.out.println("Inside ModResearch1 ");
					System.out.println("ID: "+id);
					System.out.println("NAME: "+name);
					System.out.println("GENDER: "+gender);
					System.out.println("SALARY: "+salary);
				}
				
				public ModResearch1()
				{
					System.out.println("Constructor");
				}
				
				public static void test1()
				{
					System.out.println("Static method");
				}
	
}
