package modifierpack2;

import modifierpack1.ModResearch1;

public class ModResearch4 {
	
	public void research3()
	{
		ModResearch1 mr=new ModResearch1();
		System.out.println("Inside ModResearch4 ");
		//System.out.println("ID: "+mr.id);
		//System.out.println("NAME: "+mr.name);
		//System.out.println("GENDER: "+mr.gender);
		System.out.println("SALARY: "+mr.salary);
		ModResearch1.test1();
	}
	
	public void research8() {
		ModResearch6 mr6=new ModResearch6();
	}

}
