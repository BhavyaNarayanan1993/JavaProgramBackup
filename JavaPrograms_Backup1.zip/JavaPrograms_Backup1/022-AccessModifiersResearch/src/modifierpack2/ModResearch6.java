package modifierpack2;

class ModResearch6 {

}
