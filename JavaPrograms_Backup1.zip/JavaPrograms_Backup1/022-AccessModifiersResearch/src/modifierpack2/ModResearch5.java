package modifierpack2;

import modifierpack1.ModResearch1;

public class ModResearch5 extends ModResearch1{
			
	public void research4()
	{
		System.out.println("Inside ModResearch5 ");
		//System.out.println("ID: "+id);
		//System.out.println("NAME: "+name);
		System.out.println("GENDER: "+gender);
		System.out.println("SALARY: "+salary);
		
	}
	
	public void research5() {
		ModResearch1 mr=new ModResearch1();
		System.out.println("Inside ModResearch5 ");
		//System.out.println("ID: "+mr.id);
		//System.out.println("NAME: "+mr.name);
		//System.out.println("GENDER: "+mr.gender);
		System.out.println("SALARY: "+mr.salary);
		ModResearch1.test1();
	}
}
