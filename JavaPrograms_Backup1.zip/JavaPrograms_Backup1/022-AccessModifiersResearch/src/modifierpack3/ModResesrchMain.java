package modifierpack3;

import modifierpack1.ModResearch1;


public class ModResesrchMain {
	public static void main(String[] args)
	{
		ModResearch1 mr=new ModResearch1();
		mr.research1();
		ModResearch1.test1();
		
	}
}
