
public class Main04 {

	public static void main(String[] args) {
		char[] array= {'A','B','C','D'};	//inline initialization
		
		for(char element:array)
		{
			System.out.println(element);
		}
		array=null;
	}

}
