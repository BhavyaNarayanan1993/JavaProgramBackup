
public class Main07 {

	public static void main(String[] args) {
		int[] array= {14,20,30,10};
		int sum=0;
		float average;
		
		for( int i=0;i<array.length;i++)
		{
			sum+=array[i];
		}
		average=(float)sum/array.length;
		System.out.println("Sum of array: "+sum);
		System.out.println("Average is:"+average);

	}

}
