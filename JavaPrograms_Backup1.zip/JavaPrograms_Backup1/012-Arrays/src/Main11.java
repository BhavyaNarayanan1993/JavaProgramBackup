import java.util.Arrays;

public class Main11 {

	public static void main(String[] args) {
		int size=4;
		int[] array=new int[size];
		array[0]=50;
		array[1]=80;
		array[2]=100;
		array[3]=200;
		
		System.out.println(array[5]); //indexout of bound exception
		
		System.out.println(array[-2]); //negative array size exception
		
		array=null;
			System.out.println(array.length);// null pointer exception
		
		System.out.println(Arrays.toString(array));

	}

}
