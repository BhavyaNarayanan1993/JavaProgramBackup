
public class Main08 {

	public static void main(String[] args) {
		int[] array= {14,20,30,10};
		int min=array[0];
		int max=0;
		for( int i=0;i<array.length;i++)
		{
			if(min>array[i])
				min=array[i];
			
			if(max<array[i])
				max=array[i];
		}
		System.out.println(min);
		System.out.println(max);

	}

}
