
public class Main02 {

	public static void main(String[] args) {
		double[] discount;
		discount=new double[5];
		
		System.out.println(discount.length);
		
		for(int i=0;i<discount.length;i++) {
			System.out.println(discount[i]);
		}

		discount[0]=0.15;
		discount[1]=0.5;
		discount[2]=0.22;
		discount[3]=0.18;
		
		for(int i=0;i<discount.length;i++) {
			System.out.println(discount[i]);
		}
		
		discount=null;
	}

}
