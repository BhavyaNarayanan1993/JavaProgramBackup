import java.util.Scanner;

public class Main05 {

	public static void main(String[] args) {
		int[] marks;
		int size;
		System.out.println("Enter size");
		Scanner sc=new Scanner(System.in);
		size= sc.nextInt();
		marks=new int[size];
		
		for(int i=0;i<marks.length;i++)
		{
			marks[i]=sc.nextInt();
		}
		
		for(int e:marks)
			System.out.println(e);
	}

}
