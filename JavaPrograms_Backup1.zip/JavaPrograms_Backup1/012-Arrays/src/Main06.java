import java.util.Scanner;

public class Main06 {

	public static void main(String[] args) {
		long[] profits;
		int arraySize;
		System.out.println("Enter the size:");
		Scanner sc=new Scanner(System.in);
		arraySize=sc.nextInt();
		profits=new long[arraySize];
		
		System.out.println("Enter the element:");
		for(int i=0;i<profits.length;i++)
		{
			profits[i]=sc.nextLong();
		}
		
		for(long element:profits)
		{
			System.out.println(element);
		}

	}

}
