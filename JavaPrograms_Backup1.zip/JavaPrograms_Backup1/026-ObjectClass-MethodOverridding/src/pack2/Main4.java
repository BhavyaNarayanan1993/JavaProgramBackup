package pack2;

import pack1.Student;

public class Main4 {

	public static void main(String[] args) {
		Student stud=new Student(100, "Manu", 60, 70);
		System.out.println(stud);

		Student stud1=new Student(102, "Raj", 88, 72);
		System.out.println(stud1);
	}

}
