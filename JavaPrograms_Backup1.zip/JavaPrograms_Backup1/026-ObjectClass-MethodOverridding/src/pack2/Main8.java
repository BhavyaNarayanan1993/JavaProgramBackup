package pack2;

import pack1.Student;

public class Main8 {
	
	public static void main(String[] args) {
		
		Student s1=new Student(101, "Raju", 69, 88);
		Student s2=new Student(102, "Manu", 55, 38);
		Student s3=new Student(101, "Raj", 94, 44);
		
		System.out.println(s1.equals(s2));
		System.out.println(s1.equals(s3));
		
	}
		
}
