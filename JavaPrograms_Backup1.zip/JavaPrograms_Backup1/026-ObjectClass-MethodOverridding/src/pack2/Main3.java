package pack2;

import pack1.Employee;

public class Main3 {

	public static void main(String[] args) {
		Employee emp=new Employee(101,"Kiran",5000.00,'A') ;
		System.out.println(emp);
	}

}
