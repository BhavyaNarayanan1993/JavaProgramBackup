package pack2;

import pack1.Circle;

public class Main {

	public static void main(String[] args) {
		int a=100;
		Circle c1=new Circle(10);
		
		System.out.println(a);	//100
		System.out.println(c1);  //hash string output
		System.out.println(c1.toString());	//hash string

	}

}
