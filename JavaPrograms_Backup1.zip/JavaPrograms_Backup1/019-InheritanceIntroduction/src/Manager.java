
public class Manager extends Employee{

			private int employeeCount;

			int getEmployeeCount() {
				return employeeCount;
			}

			void setEmployeeCount(int employeeCount) {
				this.employeeCount = employeeCount;
			}
			
			double computeAllowance()
			{
				return basicSalary*0.35;
			}
}
