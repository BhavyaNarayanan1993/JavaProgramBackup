
public class SalesManager extends SalesEmployee{

}
