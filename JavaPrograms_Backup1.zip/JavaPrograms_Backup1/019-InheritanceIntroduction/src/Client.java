
public class Client {

	public static void main(String[] args) {
		Manager manager=new Manager();
		manager.setId(101);
		manager.setName("Ram");
		manager.setGender("MALE");
		manager.setBasicSalary(1000.00);
		manager.setEmployeeCount(50);
		
		System.out.println("ID: "+manager.getId());
		System.out.println("NAME: "+manager.getName());
		System.out.println("GENDER: "+manager.getGender());
		System.out.println("BASIC SALARY: "+manager.getBasicSalary());
		System.out.println("EMPLOYEE COUNT: "+manager.getEmployeeCount());
		System.out.println("NET SALARY: "+manager.getNetSalary());
		
		
		SalesEmployee sale=new SalesEmployee();
		sale.setId(200);
		sale.setName("Surya");
		sale.setGender("FEMALE");
		sale.setBasicSalary(5000.00);
		sale.setSalesArea("Mumbai");
		
		System.out.println("ID: "+sale.getId());
		System.out.println("NAME: "+sale.getName());
		System.out.println("GENDER: "+sale.getGender());
		System.out.println("BASIC SALARY: "+sale.getBasicSalary());
		System.out.println("SALES AREA: "+sale.getSalesArea());
		System.out.println("NET SALARY: "+sale.getNetSalary());
	}

}
