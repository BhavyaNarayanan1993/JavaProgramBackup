
public class SalesEmployee extends Employee{
	
	private String salesArea;

	String getSalesArea() {
		return salesArea;
	}

	void setSalesArea(String salesArea) {
		this.salesArea = salesArea;
	}
	

}
