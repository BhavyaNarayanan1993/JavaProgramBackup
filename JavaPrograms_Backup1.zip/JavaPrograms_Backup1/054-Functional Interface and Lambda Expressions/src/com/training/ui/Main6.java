package com.training.ui;

import com.training.model.Acceptor;
import com.training.model.Account;
import com.training.model.BillItem;
import com.training.model.Circle;
import com.training.model.Employee;

public class Main6 {

	public static void main(String[] args) {
		Acceptor<Circle> acceptor1;
		acceptor1=c->System.out.println(c.getRadius()+","+c.getArea());
		acceptor1.accept(new Circle(90));
		
		Acceptor<Account> acceptor2;
		acceptor2=a->System.out.println(a.getCustomerName().toUpperCase()+","+a.getBalance());
		acceptor2.accept(new Account("Manu", 3000.00));
		
		Acceptor<BillItem> acceptor3;
		acceptor3=bI->System.out.println(bI.toString());
		acceptor3.accept(new BillItem("Oppo", 3, 20000.00));
		
		Acceptor<Employee> acceptor4;
		acceptor4=e->{System.out.println(e.getName()+","+e.getCityName().toUpperCase());
		System.out.println(e.getGender().toUpperCase()+","+e.getNetSalary());
		};
		acceptor4.accept(new Employee(101, "Manu", "Male", "Chennai", 30000.00));
	}

}
