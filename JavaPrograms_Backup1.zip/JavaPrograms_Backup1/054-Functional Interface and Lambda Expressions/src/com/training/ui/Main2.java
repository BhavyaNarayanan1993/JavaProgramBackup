package com.training.ui;

import com.training.model.Acceptor;
import com.training.model.Account;
import com.training.model.AccountAcceptor;
import com.training.model.BillItem;
import com.training.model.BillItemAcceptor;
import com.training.model.Circle;
import com.training.model.CircleAcceptor;

public class Main2 {

	public static void main(String[] args) {
		Acceptor<Circle> acceptor1= new CircleAcceptor();
		acceptor1.accept(new Circle(10));
		
		Acceptor<Account> acceptor2= new AccountAcceptor();
		acceptor2.accept(new Account("Manu", 3000.00));
		
		Acceptor<BillItem> acceptor3=new BillItemAcceptor();
		acceptor3.accept(new BillItem("Dell", 3, 2000.0));

	}

}
