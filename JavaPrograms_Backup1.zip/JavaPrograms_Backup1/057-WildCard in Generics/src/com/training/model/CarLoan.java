package com.training.model;

public class CarLoan extends Loan{

}
