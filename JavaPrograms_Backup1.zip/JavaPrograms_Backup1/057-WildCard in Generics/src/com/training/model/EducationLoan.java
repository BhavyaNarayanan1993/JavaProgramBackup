package com.training.model;

public class EducationLoan extends Loan{

}
