package com.training.model;

public class Loan {

}
