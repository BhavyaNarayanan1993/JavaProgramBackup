package com.training.ui;

import java.util.LinkedList;
import java.util.List;

import com.training.model.CarLoan;
import com.training.model.CollegeEducationLoan;
import com.training.model.EducationLoan;
import com.training.model.HomeLoan;
import com.training.model.Loan;

public class Main1 {

	static void print1(List<? extends Loan> loans) {
		System.out.println(loans);
	}
	
	static void print2(List<? extends CarLoan> loans) //it can be carLoan type or any of the sub classes of car loan
	{
		System.out.println(loans);
	}
	
	static void print3(List<? extends EducationLoan> loans) //educationalLoan or anything that extends educationLoan 
	{
		System.out.println(loans);
	}
	
	static void print4(List<? super EducationLoan>loans) // anything which is the super class of EductationLoan
	{
		System.out.println(loans);
	}
	
	static void print5(List<?> loans)//list of any type of object
	{
		System.out.println(loans);
	}
	
	static void print6(List<? extends HomeLoan> loans)
	{
		System.out.println(loans);
	}
	
	public static void main(String[] args) {
		List<Loan> loans=new LinkedList<>();
		print1(loans);
		
		List<CarLoan> cloans=new LinkedList<>();
		print2(cloans);
		
		List<EducationLoan> eloans=new LinkedList<>();
		print3(eloans);
		
		List<CollegeEducationLoan> celoans=new LinkedList<>();
		print3(celoans);
		
		print4(loans);
		print4(eloans);
		
		print5(loans);
		print5(cloans);
		print5(eloans);
		print5(celoans);
		
		List<Integer> ilist=new LinkedList<>();
		print5(ilist);
		
		List<HomeLoan> hloans=new LinkedList<>();
		print1(hloans);
		//print2(hloans);
		//print3(hloans);
		//print4(hloans);
		print5(hloans);
		print6(hloans);
	}

}
