package com.training.model;

public class Student {

	private int mark;
	private String name;
	private char grade;
	

	public char getGrade() {
		return grade;
	}

	public void setGrade(char grade) throws InvalidGradeException {
		if(grade!='A' ||grade!='B') {
			InvalidGradeException e1=new InvalidGradeException("Incorrect Grade:"+grade);
			throw e1;
		}
		this.grade = grade;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) throws InvalidNameException {
		if(name==null || name.length()==0) {
			InvalidNameException e=new InvalidNameException("Incorrect Name:"+name);
			throw e;
		}
		
		this.name = name;
	}

	public int getMark() {
		return mark;
	}

	public void setMark(int mark) throws InvalidMarkException{
		if(mark<0 || mark>101) {
			InvalidMarkException e= new InvalidMarkException("Incorrect Mark:"+mark);
			throw e;
		}
		this.mark = mark;
	}
	
		
		

}
