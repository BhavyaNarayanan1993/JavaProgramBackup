package com.training.model;

public class Employee {
		private double basicsalary;

		public double getBasicsalary() {
			return basicsalary;
		}

		public void setBasicsalary(double basicsalary) throws Exception  {
			if(basicsalary<0) {
				Exception e=new Exception("Incorrect BasicSalary "+basicsalary);
				throw e;
			}
			this.basicsalary = basicsalary;
		}
		
		public double computeAllowance() {
			return this.basicsalary*0.35;
		}
		
}
