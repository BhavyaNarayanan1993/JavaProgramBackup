package com.training.ui;

public class Main05 {

	public static void main(String[] args) {
		
		System.out.println("Program Begins....");
		try {
		System.out.println(100/0);
		int[] arr= {1,2,3,4,5};
		System.out.println(arr[100]);
		System.out.println(Integer.parseInt("125abcd"));
		String str=null;
		System.out.println(str.length());
		}
		catch(ArithmeticException e) {
			System.out.println("Invalid Division");
			System.out.println("continuing");
		}
		catch(ArrayIndexOutOfBoundsException e) {
			System.out.println(e);
			System.out.println("continuing");
		}
		catch(NumberFormatException e) {
			System.out.println("Invalid String data");
			System.out.println("continuing");
		}
		catch(NullPointerException e) {
			System.out.println("Null value encountered");
			System.out.println("continuing");
		}
		catch(Exception e) {
			System.out.println("Some Error Occured");
			System.out.println("continuing");
		}
		
		System.out.println("Program Ends....");
	}

}
