package com.training.ui;

import com.training.model.Student;

public class Main10 {

	public static void main(String[] args) throws Exception {
		Student student = new Student();

		try {
			student.setMark(108);
		} catch (RuntimeException e) {
			System.out.println(e);
			e.printStackTrace();
		}
		System.out.println(student.getMark());

		// student.setMark(107);

		try {
			student.setName("");
		} catch (Exception e) {
			e.printStackTrace();
		}
		// student.setName(null);
		 System.out.println(student.getName());
		 
		try {
			student.setGrade('E');
		} catch (Exception e) {
			e.printStackTrace();
		}

		System.out.println("Program Ends....");

	}

}
