package com.training.ui;

public class Main06 {

	public static void main(String[] args) {
		
		System.out.println("Program Begins....");
		try {
		System.out.println(100/0);
		int[] arr= {1,2,3,4,5};
		System.out.println(arr[100]);
		System.out.println(Integer.parseInt("125abcd"));
		String str=null;
		System.out.println(str.length());
		}
		catch(NumberFormatException e) {
			System.out.println("Some NumberFormatException occured");
			System.out.println("continuing");
		}
		catch(RuntimeException e) {
			System.out.println("Some RuntimeException occured");
			System.out.println("continuing");
		}
		catch(Exception e) {
			System.out.println("Some Error occured");
			System.out.println("continuing");
		}
		catch(Throwable e) {
			System.out.println("Some throwable Error occured");
			System.out.println("continuing");
		}
		finally {
			System.out.println("Good bye");
		}
	}

}
