package com.training.ui;

import com.training.model.Employee;

public class Main09 {

	public static void main(String[] args) {
		//System.out.println(100/0);
		Employee emp=new Employee();
		try {
			emp.setBasicsalary(-1000.0);
		} catch (Exception e) {
			
			e.printStackTrace();
		}
		
		System.out.println(emp.computeAllowance());
		

	}

}
