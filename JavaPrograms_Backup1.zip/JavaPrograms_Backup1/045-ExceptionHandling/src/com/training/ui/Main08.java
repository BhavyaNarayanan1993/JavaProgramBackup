package com.training.ui;

public class Main08 {

	public static void main(String[] args) {
		
		System.out.println("Program Begins....");
		try {
		System.out.println(100/1);
		int[] arr= {1,2,3,4,5};
		System.out.println(arr[1]);
		System.out.println(Integer.parseInt("125"));
		String str=null;
		System.out.println(str.length());
		}
		catch(NumberFormatException | NullPointerException | ArithmeticException | ArrayIndexOutOfBoundsException e) {
			//e.printStackTrace();
			if(e instanceof NumberFormatException) {
				System.out.println("Number format is invalid");
			}
			if(e instanceof NullPointerException) {
				System.out.println("Null value Encoundered");
			}
			if(e instanceof ArithmeticException) {
				System.out.println("Invalid Division");
			}
			if(e instanceof ArrayIndexOutOfBoundsException) {
				System.out.println("Invalid index");
			}
		}
		
		finally {
			System.out.println("Good bye");
		}

	}

}
