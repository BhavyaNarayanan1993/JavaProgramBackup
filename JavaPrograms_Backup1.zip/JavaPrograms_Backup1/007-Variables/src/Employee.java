
public class Employee {
	
	int empid;  //instance variable,default value 0
	String name; //instance,default value null
	
	static int count; //global variable, default value 0
	void calculateAllowance()
	{
		double allowance;  //Local variable , scope is within the function, no value is assigned
		System.out.println(allowance);//error, we need to initialize
		System.out.println(empid);//default value 0
	}
	
	void calculateTax()
	{
		double tax=0;
		System.out.println(tax);
		System.out.println(empid);
	}
	void calculatincentive(int extraHours)//Parameter value, scope limited to function, need not have initial value
	{
		System.out.println(extraHours);
	}
	
	void test() {
		int x=90;
		if(x>50) {
			System.out.println("Qualified");
			int y=100; //local variable, scope is within the if block
			System.out.println(y);
		}
		else
		{
			System.out.println(y);  //error
		}
	}
}
