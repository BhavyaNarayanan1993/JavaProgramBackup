package com.training.model.pack1;

@FunctionalInterface
public interface Task {
	int execute(int a,int b);

}
