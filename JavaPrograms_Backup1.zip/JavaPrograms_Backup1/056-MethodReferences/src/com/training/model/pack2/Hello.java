package com.training.model.pack2;

@FunctionalInterface
public interface Hello {
		void doIt();

}
