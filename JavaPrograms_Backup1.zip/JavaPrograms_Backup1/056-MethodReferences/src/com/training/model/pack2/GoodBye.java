package com.training.model.pack2;

public class GoodBye {
		public void sayGoodBye() {
			System.out.println("Thank you.. Good Bye");
		}

}
