package com.training.model.pack2;

public class Greet {
	public void greet() {
		System.out.println("Hi... How are you");
	}

}
