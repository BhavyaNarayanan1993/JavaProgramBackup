package com.training.model.pack3;

public class Employee {
		int id;

		public Employee(int id) {
			super();
			this.id = id;
		}

		@Override
		public String toString() {
			return "Employee [id=" + id + "]";
		}
		
}
