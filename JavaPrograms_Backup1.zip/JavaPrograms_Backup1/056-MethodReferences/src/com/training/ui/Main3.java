package com.training.ui;

import com.training.model.pack3.Circle;
import com.training.model.pack3.Employee;
import com.training.model.pack3.Factory;

public class Main3 {

	public static void main(String[] args) {
		Factory<Circle> factory;
		//factory=(r)->new Circle(r);
		factory=Circle::new; //method reference to a constructor
		Circle c=factory.create(10);
		System.out.println(c);
		
		Factory<Employee> factory2;
		//factory2=(i)->new Employee(i);
		factory2=Employee::new;
		Employee e=factory2.create(1001);
		System.out.println(e);
		
 
	}

}
