package com.training.ui;

import com.training.model.pack2.GoodBye;
import com.training.model.pack2.Greet;
import com.training.model.pack2.Hello;
import com.training.model.pack2.Welcome;

public class Main2 {

	public static void main(String[] args) {
		
		Hello hello;
		Welcome w=new Welcome();
		
		//hello=()->System.out.println("Welcome");
		hello=w::sayWelcome;		//method reference for non static methods
		hello.doIt();
		
		GoodBye gb=new GoodBye();
		//hello=()->System.out.println("Good Bye");
		hello=gb::sayGoodBye;
		hello.doIt();
		
		Greet g=new Greet();
		hello=g::greet;
		hello.doIt();

	}

}
