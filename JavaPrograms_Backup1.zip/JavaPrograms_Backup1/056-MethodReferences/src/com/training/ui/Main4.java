package com.training.ui;

import java.util.LinkedList;
import java.util.List;
import java.util.function.Function;

public class Main4 {

	public static void main(String[] args) {
		List<String> names=new LinkedList<>();
		names.add("Prabhu");
		names.add("Manu Menon");
		names.add("Rahul");
		names.add("Seema");
		
		Function<String, Integer> fn;
		//fn=(s)->s.length();
		fn=String::length;	//method reference
		
		Integer r=fn.apply(names.get(1));
		System.out.println(r);
		
		Function<String , String> fn1;
		//fn1=(s)->s.toUpperCase();
		fn1=String::toUpperCase;	//method reference for built-in function
		String upperstr=fn1.apply(names.get(0));
		System.out.println(upperstr);

	}

}
