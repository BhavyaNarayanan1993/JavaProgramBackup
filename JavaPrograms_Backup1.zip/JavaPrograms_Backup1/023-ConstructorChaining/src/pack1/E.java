package pack1;

public class E extends D{
	
		public E() {
			super();
			System.out.println("E constructor ");
			
		}

}
