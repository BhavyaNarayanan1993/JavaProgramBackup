package pack2;

import pack1.A;

public class Main {

	public static void main(String[] args) {
//		A obj=new A();
//		obj.display();
//		
//		A obj2=new A(5);
//		obj2.display();
		
		A obj3=new A(10,20,30);
		obj3.display();

	}

}
