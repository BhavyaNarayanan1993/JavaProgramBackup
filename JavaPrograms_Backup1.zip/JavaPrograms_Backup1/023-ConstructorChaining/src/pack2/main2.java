package pack2;

import pack1.C;

public class main2 {

	public static void main(String[] args) {
		//C obj=new C(1,2,3);
		
		//C obj2=new C(20,30);
		
		//C obj3=new C(50);
		
		C obj4=new C();

	}

}
