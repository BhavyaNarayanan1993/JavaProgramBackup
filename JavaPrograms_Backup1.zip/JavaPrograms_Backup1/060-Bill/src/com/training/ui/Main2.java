package com.training.ui;

import java.io.FileInputStream;

import java.io.InputStream;
import java.io.ObjectInputStream;

import com.training.model.Bill;

public class Main2 {

	public static void main(String[] args) {

		
		try {
			InputStream is= new FileInputStream("bill.dat");
			ObjectInputStream ois =new ObjectInputStream(is);
			
			Bill bill=(Bill)ois.readObject();
			bill.printBill();
			ois.close();
			is.close();
		} catch (Throwable e) {
			System.err.println(e.getMessage());
			System.err.println(e);
			System.exit(0);
		}
		

	}

}
