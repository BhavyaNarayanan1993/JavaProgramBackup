package com.training.model;

import java.io.Serializable;
import java.util.LinkedList;
import java.util.List;

public class Department implements Serializable{
	String name;
	String managerName;
	List<Employee> employees;
	
	public Department(String name, String managerName) {
		super();
		this.name = name;
		this.managerName = managerName;
		this.employees=new LinkedList<>();
	}
	
	public Department() {
		super();
		// TODO Auto-generated constructor stub
	}

	public void addEmployee(int id, String name, String gender, String city, double basic) {
		Employee e = new Employee(id, name, gender, city, basic);
		this.employees.add(e);
	}
	
	public boolean isEmployeePresent(int id) {
		Employee emp = new Employee();
		emp.setId(id);
		boolean result = this.employees.contains(emp);
		return result;
	}
	
	public Employee findByEmployeeId(int id) {
		Employee emp = new Employee();
		emp.setId(id);
		int indexResult = this.employees.indexOf(emp);
		if(indexResult==-1)
			return null;
		else
			return this.employees.get(indexResult);
	}
	
	public void updateEmployee(int id, String name, String gender, String city, double basic) {
		Employee emp = new Employee();
		emp.setId(id);
		int indexResult = this.employees.indexOf(emp);
		if(indexResult==-1) {
			System.out.println("Employee Not Found...");
		}
		else {
			Employee temp = new Employee(id, name, gender, city, basic);
			this.employees.set(indexResult, temp);
		}
	}
	
	public void deleteEmployee(int id) {
		Employee emp = new Employee();
		emp.setId(id);
		this.employees.remove(emp);
	}
	
	public void printReport() {
		System.out.println("Department Name : "+this.name);
		System.out.println("Manager Name : "+this.managerName);
		System.out.println("-------------------------------------------------------------------------");
		System.out.println("SlNo    ID    Name      Gender    City      Basic Salary         NetSalary");
		System.out.println("-------------------------------------------------------------------------");
		
		int slNo = 1;
		double total = 0.00;
		int maleCount = 0,femaleCount = 0;
		for(Employee e:this.employees) {
			System.out.println(slNo+" \t"+e.getId()+"   "+e.getName()+"\t"+e.getGender()+"\t"+e.getCityName()+"\t\t"
					+e.getBasic()+"\t\t"+e.getNetSalary());
			total+=e.getNetSalary();
			slNo++;
			if(e.getGender().equalsIgnoreCase("Male"))
				maleCount++;
			else
				femaleCount++;
			
		}
		
		System.out.println("-------------------------------------------------------------------------");
		System.out.println("TOTAL NET SALARY : "+total);
		System.out.println("FEMALE COUNT 	 : "+femaleCount);
		System.out.println("MALE COUNT       : "+maleCount);
		System.out.println("-------------------------------------------------------------------------");
		
		/*
		 * Department Name :
		 * Manager Name :
		 * -------------------------------------------------------------------------
		 * SlNo  ID    Name     Gender    City      Basic Salary         NetSalary
 		 * -------------------------------------------------------------------------
		 */
		
	}
	
}
