
public class Square {

	private int size;
	
	void setSize(int size) {
		if(size<0) {
			System.out.println("Invalid Radius");
			return ;
		}
		this.size=size;
	}
	int getSize() {
		return this.size;
	}
}
