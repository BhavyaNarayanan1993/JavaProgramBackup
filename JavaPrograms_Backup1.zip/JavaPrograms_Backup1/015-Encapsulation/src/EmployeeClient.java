
public class EmployeeClient {

	public static void main(String[] args) {

			Employee employee=new Employee();
			employee.setId(101);
			employee.setName("Rahul");
			employee.setBasic(1000.00);
			employee.setCityName("Mumbai");
			employee.setGrade('A');
			
			System.out.println(employee.getId());
			System.out.println(employee.getName());
			System.out.println(employee.getBasic());
			System.out.println(employee.getCityName());
			System.out.println(employee.getGrade());

	}

}
