
public class StudentClient {

	public static void main(String[] args) {

		Student stud=new Student();
		stud.setRollNumber(1);
		stud.setName("Agneya");
		stud.setMark1(170);
		stud.setMark2(89);
		stud.setGender("Femalee");
		
		System.out.println(stud.getRollNumber());
		System.out.println(stud.getName());
		System.out.println(stud.getMark1());
		System.out.println(stud.getMark2());
		System.out.println(stud.getGender());
	}

}
