package pack1;

public class C {

	
			//1.constructor overloading
			public C(){
				System.out.println("Constructor1 created");
			}
			
			public C(int a) {
				System.out.println("Constructor2 created");
			}
			
			//2.private method redefined & condsidered overloading
			//10.function name same
			private void display() {
				System.out.println("Private method1");
			}
			
			private int display(int a) {
				System.out.println("Private method2");
				return 0;
			}
			//8.Access level can change
			public int display(int a,int b) {
				System.out.println("Access level can change");
				return 0;
			}
			//3.static methods redefined & considered overloading
			//9.Static method can be overloaded
			public static void print() {
				System.out.println("Static method1");
			}
			
			public static void print(int b) {
				System.out.println("Static method2");
			}
			//6.static method overloaded as instance method
			
			public  void print(int b,int c) {
				System.out.println("Static method as instance method");
			}
			
			
			//4.return type may or may not change
			//5.parameter should change
			public void returnType() {
				System.out.println("Return type1");
			}
			
			public int returnType(int a) {
				System.out.println("Return type2");
				return 0;
			}
			
			//7.Instance method can redefine as static method
			public static int returnType(int a, int b) {
				System.out.println("Instance method as static method");
				return 0;
			}
			
			//Final method can be overloaded
			public final void finalfunc() {
				System.out.println("Final method1");
			}
			
			public final void finalfunc(int a) {
				System.out.println("Final method2");
			}
}
