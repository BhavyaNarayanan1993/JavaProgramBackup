package pack1;

public class D  extends C{

			//1.constructor overriding doesnot work
			public D() {
				System.out.println("Constructor2 created");
			}
			
			//2.private method redefined, not overridden
			//10.Function name same
			@Override
			private void display() {
				System.out.println("Private method 3 redefined ");
			}
			//8.Access level should be same or increased
			@Override
			public void display(int a) {
				System.out.println("Access level increased");
			}
			
			//3.static methods redefined & not overridden
			//9.static method cannot be overridden
			@Override
			public static void print(int a) {
				System.out.println("Static method3");
			}
			
			//6.static method cannot be redefined as instance method 
			@Override
			public void print(int a) {
				System.out.println("Static method cannot redefine");
			}
			
			//4.return type should be same
			//5.parameter should not change
			@Override
			public int returnType(int a) {
				System.out.println("Return type same");
				return 0;
			}
			
			//7.Instance method cannot be redefine as static method
			@Override
			public static int returnType(int a) {
				System.out.println("Instance method as static method");
				return 0;
			}
			
			//Final method cannot be overridden
			@Override
			public final void finalfunc(int a) {
				System.out.println("Final method annot be overridden");
			}
}
