package pack2;

import pack1.Employee;
import pack1.Manager;

public class Main1 {
	public static void main(String[] args) {
		Employee emp=new Employee();
		emp.basicSalary=1000.0;
		//System.out.println(emp.computeNetSalary());
		//System.out.println(emp.computeAllowance());
		System.out.println(emp.computeTax());
		
		Manager manager=new Manager();
		manager.basicSalary=1000.0;
		manager.empCount=10;
		//System.out.println(manager.computeNetSalary());
		//System.out.println(manager.computeAllowance());
		System.out.println(manager.computeTax());
	}

}
