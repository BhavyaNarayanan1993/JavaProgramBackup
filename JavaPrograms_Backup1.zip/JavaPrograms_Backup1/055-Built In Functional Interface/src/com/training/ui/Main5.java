package com.training.ui;

import java.util.function.Function;

import com.training.model.Circle;
import com.training.model.Employee;
import com.training.model.Payment;
import com.training.model.Person;
import com.training.model.Square;

public class Main5 {

	public static void main(String[] args) {
		Function<Integer, Circle> function1;
		function1=(Integer i)->{
			return new Circle(i.intValue());
		};
		Circle c=function1.apply(5);
		System.out.println(c);
		
		Function<Integer, Square> function2;
		function2=i->new Square(i.intValue());
		Square s=function2.apply(6);
		System.out.println(s);
		
		Function<Employee,String> function3;
		function3=(e)->e.getName();
		
		Employee e= new Employee(101, "Hari", "Male", "Delhi", 20000.00);
		
		String ename=function3.apply(e);
		System.out.println(ename);
		
		Function<Employee,String> function4;
		function4=(emp)->emp.getCityName();
		String ecity=function4.apply(e);
		System.out.println(ecity);
		
		Function<Employee,Double> function5;
		function5=(emp)->emp.getBasic();
		Double ebasic=function5.apply(e);
		System.out.println(ebasic);
		
		Payment payment=new Payment("January", 15000.00);
		
		Function<Payment,String> function6;
		function6=(pay)->pay.getMonth();
		String payMonth=function6.apply(payment);
		System.out.println(payMonth);
		
		Function<Payment,Double> function7;
		function7=(pay)->pay.getPaymentAmount();
		Double payAmount=function7.apply(payment);
		System.out.println(payAmount);
		
		Person person=new Person("Manu", 25);
		
		Function<Person,String> function8;
		function8=(per)->per.getName();
		String perName=function8.apply(person);
		System.out.println(perName);
		
		Function<Person,Integer> function9;
		function9=(per)->per.getAge();
		Integer perAge=function9.apply(person);
		System.out.println(perAge);

	}
}
