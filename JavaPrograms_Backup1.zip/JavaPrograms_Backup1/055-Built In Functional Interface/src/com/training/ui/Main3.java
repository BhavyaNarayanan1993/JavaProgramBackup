package com.training.ui;

import java.util.function.Predicate;

import com.training.model.Circle;
import com.training.model.Course;
import com.training.model.Department;
import com.training.model.Square;

public class Main3 {
	
	static void process1(Predicate<Circle> predicate) {
		Circle c =new Circle(20);
		System.out.println(predicate.test(c));
	}
	
	static void process2(Predicate<Square> predicate) {
		Square s=new Square(100);
		System.out.println(predicate.test(s));
	}
	
	static void process3(Predicate<Department> predicate) {
		Department department=new Department("IT", "Kiran");
		
		department.addEmployee(101,"Manu","Male","Delhi",1000.00);
		department.addEmployee(102,"Meena","Female","Pune",2000.00);
		department.addEmployee(103,"Reenu","Female","Mumbai",4000.00);
		department.addEmployee(104,"Manoj","Male","Delhi",5000.00);
		System.out.println(predicate.test(department));
	}
	
	static void process4(Predicate<Course> predicate) {
		Course course=new Course("Diploma in Web development");
		
		course.addCourseItem("HTML",40,4500.00);
		course.addCourseItem("CSS",20,2500.00);
		course.addCourseItem("jQuery",30,3500.00);
		course.addCourseItem("Knockout js",15,1500.00);
		course.addCourseItem("Angular",50,7500.00);
		System.out.println(predicate.test(course));
		
	}

	public static void main(String[] args) {
		process1(
				circle->circle.getRadius()>=10
				);
		process2(
				square->square.getSize()>=50
				);
		process3(
				(d)->d.getEmployees().size()>=10
				);
		process4(
				(course)->course.getCourseItems().size()>=3
				);
		
	}

}
