
public class B {
			
		void calculateTotal(int a, int b) {
			int sum=a+b;
			System.out.println("Sum is "+sum);
		}
		
		static void calculateTotal(int a, float b) {
			float sum=a+b;
			System.out.println("Sum is "+sum);
		}
		
		void calculateTotal()
		{
			System.out.println("Sum");
		}
		
		void calculateTotal(int a, float b, long c)
		{
			float sum=a+b+c;
			System.out.println("Sum is "+sum);
		}
		
		int calculateTotal(boolean isAvailable, int a,int b) {
			System.out.println("Sum "+isAvailable);
			int sum = 0;
			if(isAvailable)
			{
				sum=a+b;
			}
			return sum;
		}
}
