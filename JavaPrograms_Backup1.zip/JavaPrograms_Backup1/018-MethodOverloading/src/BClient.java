
public class BClient {

	public static void main(String[] args) {
		B obj=new B();
		obj.calculateTotal(10, 20);
		obj.calculateTotal(20, 120.00f, 100);
		obj.calculateTotal();
		System.out.println("Sum is "+obj.calculateTotal(true,10,20));
		B.calculateTotal(100, 500.00f);

	}

}
