import java.util.Arrays;

public class C {

	void display(double p)
	{
		System.out.println("display with long "+p);
	}
	
	void display (short p) {
		System.out.println("display with short "+p);
	}
	
	void display(int p)
	{
		System.out.println("display with int "+p);
	}
	
	void display(int... a)
	{
		System.out.println("display with int[] "+Arrays.toString(a));
	}
	
	
}
