
public class CClient {

	public static void main(String[] args) {
		
		C obj=new C();
		obj.display(100);
		
		int v1=900;
		obj.display(v1);
		
		short v2=800;
		obj.display(v2);
		
		byte v3=77;
		char v4='A';
		long v5=900;
		
		obj.display(v3);
		obj.display(v4);
		obj.display(v5);
		
		float v6=123.9f;
		double v7=90.0;
		
		//obj.display(v6);
		//obj.display(v7);
		
		obj.display(10,20,30,40,50);
		obj.display(new int[] {1,2,3,4,5});
		
		obj.display((byte)100);
	}

}
