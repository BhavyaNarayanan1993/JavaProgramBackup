import java.util.Scanner;

public class Main4 {

	public static void main(String[] args) {
		int menuChoice;
		do {
			System.out.println("Menu Options");
			System.out.println("1.Add Employee");
			System.out.println("2.Search Employee");
			System.out.println("3.Display All Employees");
			System.out.println("4.Delete an Employee");
			System.out.println("5.Exit");
			System.out.println("Enter MenuChoice");
			Scanner sc = new Scanner(System.in);
			menuChoice = sc.nextInt();
			System.out.println("Menu Choice is :" + menuChoice);

		} while (menuChoice != 5);

	}

}
