
public class Main1 {

	public static void main(String[] args) {
		
		int count=1;
		while(count<=10) {
		System.out.print("welcome ");
		System.out.print("to ");
		System.out.println("Training");
		count++;
		}
		System.out.println("Thank you");
	}

}
