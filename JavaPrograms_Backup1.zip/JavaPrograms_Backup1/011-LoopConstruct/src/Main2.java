
public class Main2 {

	public static void main(String[] args) {
		int count=0;
		do {
			System.out.print("welcome ");
			System.out.print("to ");
			System.out.println("Training");
			count++;
		}while(count<=10);
		System.out.println("Thank you");
	}

}
