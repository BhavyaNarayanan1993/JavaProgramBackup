
public class Main6 {

	public static void main(String[] args) {
		for(int i=500;i<=1000;i++)
		{
			int value1;
			value1=i%10;
			if(value1==0)
			{
				System.out.println(i);
			}
		}
		System.out.println("---------------------------------------");
		
		for(int j=2000;j>=1000;j--)
		{
			int value2;
			value2=j%5;
			if(value2==0)
			{
			System.out.println(j);
			}
		}

	}

}
