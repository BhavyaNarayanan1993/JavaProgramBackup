
public class Main4 {

	public static void main(String[] args) {
		int v1=40;
		long v2=900;
		long result1=v1+v2+100;
		float result2=v1+v2+10.0f;
		
		byte v3=88;
		short v4=99;
		double result3=v3+v4+v2+10.0; //10.0is double value.this is higher so stored in double

		int result4=v3+10+20*40;
	}

}
