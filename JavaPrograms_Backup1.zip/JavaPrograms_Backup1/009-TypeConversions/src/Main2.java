
public class Main2 {
	public static void main(String[] args)
	{
		int v1=100;
		//short v2=v1;   error as int is big
		short v2=(short)v1; //narrow conversion, explicit
		byte v3=(byte)v2;//same
		
		char a='A';
		byte b=(byte)a;
		
		double v4=90.0;
		byte v5=(byte)v4;//narrow conversion, explicit
		short v6=(short)v4;//narrow conversion, explicit
		int v7=(int)v4;//narrow conversion, explicit
		long v8=(long)v4;//narrow conversion, explicit
		float v9=(float)v4;//narrow conversion, explicit
		char v10=(char)v4;//narrow conversion, explicit
		//boolean v11=(boolean)v4;//error
	}

}
