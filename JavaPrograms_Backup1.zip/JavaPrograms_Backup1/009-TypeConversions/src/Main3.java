
public class Main3 {

	public static void main(String[] args) {
		
		int v1=30;
		int v2=40;
		long v3=50;
		double v4=60;
		int result1= v1+v2; //single mode expression
		long result2=v1+v2+v3; //mixed mode expression
		double result3=v1+v2+v3+v4;
		
		byte v5=6;
		short v6=7;
		int result4=v5+v6;// the expression which involve byte and short, the result is int
		
		int result5=(int)(v1+v2+v3);
		float result6=(float)(v1+v2+v3+v4);
	}

}
