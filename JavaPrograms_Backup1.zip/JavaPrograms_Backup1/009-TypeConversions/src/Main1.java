
public class Main1 {

	public static void main(String[] args) {
		byte v1=100;
		short v2=v1; //type conversion, implicitly will do type conversion, widening conversion 
		int v3=v2;//same
		long v4=v3;
		float v5=v4;
		double v6=v5;
		
		//char v7=v2;
		
		int v7=v2;
		char v8='A';
		int v9=v8;
	}

}
