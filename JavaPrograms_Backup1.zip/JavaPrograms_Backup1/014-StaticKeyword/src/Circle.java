
public class Circle {

	int radius;
	static double PI=3.14;
	
	double getArea() {
		
		double area=PI*radius*radius;
		return area;
		
	}
}
