
public class A {

	int x;
	static int y;
	
	void display1() {
		System.out.println(x);
		System.out.println(y);
	}
	
	static void welcome()
	{
		System.out.println("WELCOME");
		System.out.println(y);
	}
}
