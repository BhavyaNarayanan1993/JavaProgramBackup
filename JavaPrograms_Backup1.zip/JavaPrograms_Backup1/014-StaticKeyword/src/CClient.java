
public class CClient {

	public static void main(String[] args) {
		
		C.count=0;  
		C.printCount();
		
		C obj=new C();
		obj.name="UST Global";
		C.count++;
		obj.printName();
		C.printCount();
		
		C obj2=new C();
		obj2.name="Bhavya";
		C.count++;
		obj2.printName();
		C.printCount();
		
		C obj3=new C();
		obj3.name="Karthick";
		C.count++;
		obj3.printName();
		C.printCount();
		
	}

}
