
public class B {

	static String companyName="UST";
	String location;
	
	static void greet()
	{
		System.out.println("How are you");
	}
	
	void goodbye() {
		System.out.println("Thank you and bye");
	}
}
