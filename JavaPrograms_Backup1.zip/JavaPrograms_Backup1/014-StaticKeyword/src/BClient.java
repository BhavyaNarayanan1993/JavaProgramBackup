
public class BClient {

	public static void main(String[] args) {
		System.out.println(B.companyName);
		
		B obj=new B();
		obj.location="TVM";
		System.out.println(obj.location);
		
		B.greet();
		obj.goodbye();

	}

}
