
public class Main8 {

	public static void main(String[] args) {

		short size=20;
		
		final int aValue=100;// we can use aValue as case labels if we use final
		switch(size) {
		case 50: System.out.println("Welcome 1");
		break;
		case aValue: System.out.println("welcome 2");
		break;
		case 200: System.out.println("Welcome 3");
		break;
		}

	}

}
