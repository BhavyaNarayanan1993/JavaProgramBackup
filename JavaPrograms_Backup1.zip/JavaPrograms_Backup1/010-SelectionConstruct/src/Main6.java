import java.util.Scanner;

public class Main6 {

	public static void main(String[] args) {
		int mark1, mark2;
		float average;
		char grade;
		System.out.println("Enter Mark1 and Mark2");
		Scanner sc=new Scanner(System.in);
		mark1=sc.nextInt();
		mark2=sc.nextInt();
		average=(mark1+mark2)/2.0f;
		if(average>=80 && average<=100)
			grade='A';
		
		else if(average>=60 && average<80)
			grade='B';
	
		else if(average>=40 && average<60)
			grade='C';
		
		else 
			grade='D';

		if(grade=='A')
			System.out.println("Scholorship is Rs.50000.00");
		
		else if(grade=='B')
			System.out.println("Scholorship is Rs.40000.00");
		
		else if(grade=='C')
			System.out.println("Scholorship is Rs.30000.00");
		
		else
			System.out.println("Scholorship is Rs.0.00");
	}

}
