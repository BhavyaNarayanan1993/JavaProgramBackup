
public class Main9 {
	
	public static void main(String[] args)
	{
		String city="Mumbai";
		
		switch(city) {
		case "Mumbai":
		}
	}
}
