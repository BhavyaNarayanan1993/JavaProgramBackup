
public class Main4 {

	public static void main(String[] args) {
		int marks;
		marks=66;
		char grade;
		if(marks>=90)
		{
			grade='A';
			System.out.println("You are eligible for Scholarship");
		}
		else if(marks>=70)
		{
			grade='B';
			System.out.println("You are eligible for Scholarship");
		}
		else if(marks>=50)
		{
			grade='C';
			System.out.println("You are not eligible for Scholarship");
		}
		else
		{
			grade='D';
			System.out.println("You are not eligible for Scholarship");
		}
		System.out.println(grade);
	}

}
