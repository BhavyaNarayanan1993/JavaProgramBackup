
public class Main2 {

	public static void main(String[] args) {
		
		int age=44;
		//selecion construct
		if(age>=18) {
		System.out.println("your age is above 18");
		System.out.println("You are eligible for voting");
		}
	}

}
