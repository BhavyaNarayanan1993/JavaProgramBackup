
public class Main3 {

	public static void main(String[] args) {
		int age=10;
		//selecion construct
		if(age>=18) {
		System.out.println("your age is above 18");
		System.out.println("You are eligible for voting");
		}
		else {
			System.out.println("your age is below 18");
			System.out.println("You are  not eligible for voting");
		}

	}

}
