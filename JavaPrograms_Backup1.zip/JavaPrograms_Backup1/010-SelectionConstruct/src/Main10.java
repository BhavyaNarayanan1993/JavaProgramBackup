import java.util.Scanner;

public class Main10 {

	public static void main(String[] args) {
		int currentQuantity;
		System.out.println("Enter the current quntity: ");
		
		Scanner sc=new Scanner(System.in);
		currentQuantity=sc.nextInt();
		
		final int aValue=10,bValue=20,cValue=30,dValue=50;
		
		switch(currentQuantity) {
		case aValue:	System.out.println("Stock level very Low");
						break;
		case bValue:	System.out.println("Stock level Low");
						break;
		case cValue:	System.out.println("Stock level Low");
						break;
		case dValue:	System.out.println("Stock level OK");
						break;
		default:		System.out.println("Invalid Stock Level");
		}
		

	}

}
