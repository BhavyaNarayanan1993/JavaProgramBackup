import java.util.Scanner;

public class Main5 {

	public static void main(String[] args) {
		int qty;
		System.out.println("Enter the quantity: ");
		Scanner sc=new Scanner(System.in);
		qty=sc.nextInt();
		if(qty>=90)
			System.out.println("*****");
		
		else if(qty>=70)
			System.out.println("****");
		
		else if(qty>=50)
			System.out.println("***");
		
		else
			System.out.println("**");
		

	}

}
