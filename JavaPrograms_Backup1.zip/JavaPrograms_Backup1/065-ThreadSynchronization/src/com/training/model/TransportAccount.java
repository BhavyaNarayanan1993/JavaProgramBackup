package com.training.model;

public class TransportAccount {
	int ticketCount;

	public void bookTicket(int count) {
		String tname=Thread.currentThread().getName();
		for(int i=1;i<=count;i++) {
			synchronized (this) {
				this.ticketCount++;
				if(this.ticketCount>=35) {
					try {
						notify();
						wait();
					} catch (InterruptedException e) {
						
						e.printStackTrace();
					}
				}	
			}
			
			System.out.println(tname+" : Booking.."+this.ticketCount);
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
				
				e.printStackTrace();
			}
		}
		notify();
		System.out.println("Booking Tickets with count : "+count);
		
	}
	
	public void cancelTicket(int count) {
		String tname=Thread.currentThread().getName();
		for(int i=1;i<=count;i++) {
			synchronized (this) {
				this.ticketCount--;
				if(this.ticketCount<=10) {
					try {
						notify();
						wait();
					} catch (InterruptedException e) {
						
						e.printStackTrace();
					}
				}
			}
			
			System.out.println(tname+" : Cancelling.."+this.ticketCount);
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
				
				e.printStackTrace();
			}
		}
		notify();
		System.out.println("Cancelling Tickets with count : "+count);
		
	}

}
