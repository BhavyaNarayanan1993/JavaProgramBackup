package com.training.task;

public class Counter {
	
	int count=0;

	public synchronized int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}
	
	public synchronized void increment() {
		for(int i=0;i<=10;i++)
		{
			count++;
			String tname=Thread.currentThread().getName();
			System.out.println(tname+" : "+count);
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				
				e.printStackTrace();
			}
		}
	}

}
