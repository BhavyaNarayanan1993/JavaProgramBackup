package com.training.task;

import com.training.model.TransportAccount;

public class BookTicketTask implements Runnable{
	TransportAccount tacc;
	

	public BookTicketTask(TransportAccount tacc) {
		super();
		this.tacc = tacc;
	}


	@Override
	public void run() {
		tacc.bookTicket(40);
		
	}
	

}
