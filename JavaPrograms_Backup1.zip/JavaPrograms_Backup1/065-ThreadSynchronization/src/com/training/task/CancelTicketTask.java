package com.training.task;

import com.training.model.TransportAccount;

public class CancelTicketTask implements Runnable{
	TransportAccount tacc;

	
	public CancelTicketTask(TransportAccount tacc) {
		super();
		this.tacc = tacc;
	}

	@Override
	public void run() {
		tacc.cancelTicket(10);
		
	}
	

}
