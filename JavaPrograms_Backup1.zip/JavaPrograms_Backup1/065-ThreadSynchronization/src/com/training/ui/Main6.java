package com.training.ui;

import com.training.model.TransportAccount;
import com.training.task.BookTicketTask;
import com.training.task.CancelTicketTask;


public class Main6 {

	public static void main(String[] args) {
		TransportAccount acc=new TransportAccount();
		Runnable runnable1=new BookTicketTask(acc);
		Runnable runnable2=new CancelTicketTask(acc);
		
		Thread th1=new Thread(runnable1, "BTT");
		Thread th2=new Thread(runnable2, "CTT");
		
		th1.start();
		th2.start();


	}

}
