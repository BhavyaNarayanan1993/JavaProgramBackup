package com.training.model;

public interface X {
	default void method1() {
		System.out.println("Method 1 in X inteface");
	}
	
	static void method2() {
		System.out.println("Method 2 in X Inteface");
	}
	public void method3();
}
