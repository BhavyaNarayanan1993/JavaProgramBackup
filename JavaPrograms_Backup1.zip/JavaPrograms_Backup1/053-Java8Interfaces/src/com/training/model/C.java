package com.training.model;

public class C implements A,B,X{

	@Override
	public void f1() {
		System.out.println("f1 in C Class");
		
	}
	@Override
	public void f2() {
		System.out.println("F2 in C class");
	}
	@Override
	public void f4() {
		System.out.println("f4 in Class C");
	}
	
	static void f5() {
		System.out.println("Static ");
	}
	@Override
	public void method3() {
		System.out.println("Method 3 in Class C");
		
	}
	
	@Override
	public void method1() {
		System.out.println("Method 1 in Class C");
	}
	

}
