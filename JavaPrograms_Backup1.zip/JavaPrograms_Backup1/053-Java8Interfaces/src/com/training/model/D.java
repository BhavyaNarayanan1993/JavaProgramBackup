package com.training.model;

public class D implements A,X{

	@Override
	public void f1() {
		System.out.println("F1 in D class");
		
	}
	
	@Override
	public void f2() {
		System.out.println("F2 in D class");
	}
	@Override
	public void f4() {
		System.out.println("f4 in Class D");
	}

	@Override
	public void method3() {
		System.out.println("Method 3 in Class D");
		
	}

}
