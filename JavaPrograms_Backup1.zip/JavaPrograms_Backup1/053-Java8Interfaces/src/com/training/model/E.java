package com.training.model;

public class E implements A,X{

	@Override
	public void f1() {
		System.out.println("f1 in E class");
		
	}
	
	@Override
	public void f2() {
		System.out.println("F2 in E class");
	}

	@Override
	public void f4() {
		System.out.println("f4 in Class E");
	}

	@Override
	public void method3() {
		System.out.println("Method3 in Class E");
		
	}
}
