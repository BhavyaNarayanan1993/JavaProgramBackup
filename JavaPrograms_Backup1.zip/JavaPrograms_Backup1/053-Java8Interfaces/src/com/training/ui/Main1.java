package com.training.ui;

import com.training.model.A;
import com.training.model.C;
import com.training.model.D;
import com.training.model.E;
import com.training.model.X;

public class Main1 {

	public static void main(String[] args) {
		A obj;
		obj=new C();
		obj.f1();
		obj.f2();
		A.f5();
		
		X obj1;
		obj1=new C();
		obj1.method1();
		obj1.method3();
		X.method2();
		
		obj1=new D();
		obj1.method1();
		obj1.method3();
		X.method2();
		
		obj1=new E();
		obj1.method1();
		obj1.method3();
		X.method2();
		
		
		

	}

}
