package com.training.ui;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.OutputStream;

import com.training.model.Department;
import com.training.model.Employee;
import com.training.util.ConsoleIO;

public class Main1 {

	public static void main(String[] args) throws IOException {
		//take input for department
		//department should contain atleast 3 employee
		//serialize
		
		String name;
		String managerName;
		
		System.out.println("Enter the Department name: ");
		name=ConsoleIO.inputString();
		
		System.out.println("Enter Manager Name");
		managerName=ConsoleIO.inputString();
		
		char option;
		Department dept=new Department(name, managerName);
		do {
			int id;
			String empname;
			String gender;
			String cityName;
			double basic;
			 
			System.out.println("Enter Employee Id:");
			id=ConsoleIO.inputInt();
				
			System.out.println("Enter Employee Name:");
			empname=ConsoleIO.inputString();
				
			System.out.println("Enter Employee Gender:");
			gender=ConsoleIO.inputString();
			
			System.out.println("Enter Employee CityName:");
			cityName=ConsoleIO.inputString();
			
			System.out.println("Enter Employee Basic:");
			basic=ConsoleIO.inputDouble();
			
			dept.addEmployee(id, empname, gender, cityName, basic);
			
			System.out.println("Add More Items ? :");
			option=ConsoleIO.inputChar();
		}while(option=='Y' || option=='y');
		
		dept.printReport();
		
		try {
			OutputStream os=new FileOutputStream("dept.dat");
			ObjectOutputStream oos=new ObjectOutputStream(os);
			
			oos.writeObject(dept); 
			
			oos.flush();
			oos.close();
			os.close();
		} catch (Throwable e) {
			System.err.println(e.getMessage());
			System.out.println(e);
			System.exit(0);
		}

	}

}
