package pack2;

public class RetailBusinessLoan extends BusinessLoan{

	public RetailBusinessLoan(double loanAmount, int tenture, String customerName, String companyName) {
		super(loanAmount, tenture, customerName, companyName);
		// TODO Auto-generated constructor stub
	}

	@Override
	public double getInterestRate() {
		return 0.34;
	}
	
	
	

}
