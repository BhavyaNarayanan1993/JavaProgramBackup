package pack2;

public abstract class BusinessLoan extends Loan{
		private String companyName;

		public BusinessLoan(double loanAmount, int tenture, String customerName, String companyName) {
			super(loanAmount, tenture, customerName);
			this.companyName = companyName;
		}
		
		
		
}
