package pack2;

public class HomeLoan extends Loan{
			private String location;

			public HomeLoan(double loanAmount, int tenture, String customerName, String location) {
				super(loanAmount, tenture, customerName);
				this.location = location;
			}

			@Override
			public double getInterestRate() {
				return 0.11;
			}
			
			
}
