package pack2;

public class PersonalLoan extends Loan {
		private double monthlySalary;

		
		public PersonalLoan(double loanAmount, int tenture, String customerName, double monthlySalary) {
			super(loanAmount, tenture, customerName);
			this.monthlySalary = monthlySalary;
		}


		@Override
		public double getInterestRate() {
			return 0.21;
		}
		
}
