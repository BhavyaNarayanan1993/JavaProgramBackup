package pack2;

public abstract class Loan {
		private double loanAmount;
		private int tenture;
		private String customerName;
		
		public Loan(double loanAmount, int tenture, String customerName) {
			super();
			this.loanAmount = loanAmount;
			this.tenture = tenture;
			this.customerName = customerName;
		}
		
		public abstract double getInterestRate();
		
}
