package pack2;

public class CarLoan  extends Loan{
		private String regNumber;

		public CarLoan(double loanAmount, int tenture, String customerName, String regNumber) {
			super(loanAmount, tenture, customerName);
			this.regNumber = regNumber;
		}
		
		@Override
		public double getInterestRate() {
		
			return 0.15;
		}
}
