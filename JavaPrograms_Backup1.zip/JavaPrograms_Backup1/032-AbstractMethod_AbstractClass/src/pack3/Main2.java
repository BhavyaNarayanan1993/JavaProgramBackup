package pack3;

import pack2.BusinessLoan;
import pack2.CarLoan;
import pack2.EducationLoan;
import pack2.HomeLoan;
import pack2.Loan;
import pack2.PersonalLoan;
import pack2.RetailBusinessLoan;
import pack2.WholeSaleBusinessLoan;

public class Main2 {

	public static void main(String[] args) {
		Loan loan;
		//loan=new Loan(10000,12,"Ram");
		//System.out.println(loan.getInterestRate());
		
		loan=new CarLoan(100000, 12, "Kiran", "KL7 8652");
		System.out.println(loan.getInterestRate());
		
		loan=new HomeLoan(800000, 12, "Kiara","Kochi");
		System.out.println(loan.getInterestRate());
		
		loan=new PersonalLoan(600000, 12, "Ram",123456.00);
		System.out.println(loan.getInterestRate());
		
		loan=new EducationLoan(50000, 12, "Manu", 50);
		System.out.println(loan.getInterestRate());
		
		BusinessLoan loan1;
		loan1=new RetailBusinessLoan(30000, 12, "Manoj", "UST");
		System.out.println(loan1.getInterestRate());
		
		loan1=new WholeSaleBusinessLoan(45600, 14, "Jaya", "TATA");
		System.out.println(loan1.getInterestRate());
		
	}

}
