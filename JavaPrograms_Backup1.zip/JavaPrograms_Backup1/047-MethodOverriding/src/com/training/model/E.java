package com.training.model;

public abstract class E {
	
	public abstract void print(int n) throws Exception;

}
