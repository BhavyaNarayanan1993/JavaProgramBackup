package com.training.model;

public class Bike extends Vehicle {

}
