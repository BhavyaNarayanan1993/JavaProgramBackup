package com.training.model;

public class Y implements X{

	@Override
	public void print(int n) throws Exception {
		if(n<0) {
			throw new Exception("xyz");
		}
		
	}

	@Override
	public void test(double d) throws Exception{
		if(d<100) {
			throw new Exception("abcd");
			
		}
		
	}

}
