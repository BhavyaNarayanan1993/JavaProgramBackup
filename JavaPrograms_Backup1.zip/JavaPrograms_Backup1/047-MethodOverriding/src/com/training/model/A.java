package com.training.model;

import java.io.IOException;
import java.sql.SQLException;

public class A {
	public void test1() throws SQLException,IOException{
		
	}
	public void test2() throws Throwable{
		
	}
}
