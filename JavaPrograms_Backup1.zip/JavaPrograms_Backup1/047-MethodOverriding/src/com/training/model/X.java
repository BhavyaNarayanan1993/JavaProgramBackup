package com.training.model;

public interface X {
	void print(int n) throws Exception;
	void test(double d) throws Exception;

}
