package com.training.model;

public class K extends I{
	
	@Override
	public Bike create() {
		return new Bike();
	
	
	}

}
