package pack3;

import pack1.A;
import pack2.D;
import pack2.E;

//import pack2.F;

public class Main {
	
	public static void main(String[] args)
	{
		A obj=new A();
		obj.display();
	}

}
