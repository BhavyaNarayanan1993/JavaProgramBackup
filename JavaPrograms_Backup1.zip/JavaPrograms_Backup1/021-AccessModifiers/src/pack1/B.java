package pack1;

public class B {

	
		public void test2() {
			A obj=new A();
			//System.out.println(obj.v1);//cannot access as v1 is private variable
			System.out.println(obj.v2);
			System.out.println(obj.v3);
			System.out.println(obj.v4);
		}
}
