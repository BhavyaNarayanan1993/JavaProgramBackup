package com.training.ui;

import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

import com.training.model.BillItem;
import com.training.model.comparators.BillItemPriceComparator;

public class Main3 {

	public static void main(String[] args) {
		
		List<BillItem> billItem = new LinkedList();
		
		billItem.add(new BillItem("Redmi", 10, 10000.00));
		billItem.add(new BillItem("Oppo", 15, 15000.00));
		billItem.add(new BillItem("Lenovo", 12, 12000.00));
		billItem.add(new BillItem("Redmi", 20, 40000.00));
		billItem.add(new BillItem("OnePlus", 25, 50000.00));
		billItem.add(new BillItem("VIVO", 50, 25000.00));
		
	    System.out.println(billItem);
	    System.out.println("--------------------------------------------------");
	    Collections.sort(billItem);
	    System.out.println(billItem);
	    System.out.println("--------------------------------------------------");
	    
	    BillItem minBillItem=Collections.min(billItem,new BillItemPriceComparator());
	    System.out.println(minBillItem);
	    System.out.println("--------------------------------------------------");
	    
	    BillItem maxBillItem=Collections.max(billItem,new BillItemPriceComparator());
	    System.out.println(maxBillItem);
	    System.out.println("--------------------------------------------------");
	    
	    
	    Object[] billItemArr=billItem.toArray();
		for(Object obj:billItemArr) {
			System.out.println(obj.toString());
			BillItem bi=(BillItem) obj;
			System.out.println(bi.getItemValue());
		}

	}

}
