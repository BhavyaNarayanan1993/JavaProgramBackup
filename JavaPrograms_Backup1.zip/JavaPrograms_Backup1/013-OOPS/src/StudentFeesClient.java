import java.util.Scanner;

public class StudentFeesClient {

	public static void main(String[] args) {
		double tutnfees, extrafees;
		StudentFees sf=new StudentFees();
		
		System.out.println("Enter the Tutuion fees: ");
		Scanner sc=new Scanner(System.in);
		tutnfees=sc.nextDouble();
		System.out.println("Enter the Extra fees: ");
		extrafees=sc.nextInt();
		
		sf.calculateFees(tutnfees,extrafees);

		sf.displayFees();
		
		StudentFees sf2=new StudentFees();
		
		System.out.println("Enter the Tutuion fees: ");
		tutnfees=sc.nextDouble();
		System.out.println("Enter the Extra fees: ");
		extrafees=sc.nextInt();
		
		sf2.calculateFees(tutnfees,extrafees);

		sf2.displayFees();

	}

}
