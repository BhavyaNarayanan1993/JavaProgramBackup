
public class Employee {
	double basicsalary;
	char grade;
	
	double calculateAllowance() {
		double result;
		switch(grade) {
		case 'A': 	result=basicsalary*0.35;
					break;
		case 'B': 	result=basicsalary*0.25;
					break;
		case 'C': 	result=basicsalary*0.15;
					break;
		default:	result=0;
					break;
		}
		
		return result;
	}
	
	double calculateDeduction() {
		double result;
		switch(grade) {
		case 'A': 	result=basicsalary*0.28;
					break;
		case 'B': 	result=basicsalary*0.20;
					break;
		case 'C': 	result=basicsalary*0.10;
					break;
		default:	result=0;
					break;
		}
		
		return result;
	}
	
	double netSalary()
	{
		return basicsalary+calculateAllowance()-calculateDeduction();
	}

}
