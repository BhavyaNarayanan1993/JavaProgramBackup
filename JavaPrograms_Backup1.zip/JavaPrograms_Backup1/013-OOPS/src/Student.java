
public class Student {
		
		String name;
		int mark1,mark2;
		
		int computeTotal()
		{
			return mark1+mark2;
		}
		
		int getAverage()
		{
			return (computeTotal())/2;
		}
		
		char determineGrade() {
			char grade;
			int average=getAverage();
			if(average>=80)
				grade='A';
			else if(average>60 && average<80)
				grade='B';
			else if(average>40 && average<60)
				grade='C';
			else
				grade='D';
			
			return grade;
		}
}
