
public class StudentFees {

	double totalfees;
	
	void calculateFees(double tutionfees, double extracirfees)
	{
		totalfees=tutionfees+extracirfees;
	}
	
	void displayFees()
	{
		System.out.println("TotalFees :"+totalfees);
	}
}
