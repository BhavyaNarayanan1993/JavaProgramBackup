import java.util.Scanner;

public class StudentClient {

	public static void main(String[] args) {

		Student s1=new Student();
		System.out.println("Enter student name: ");
		Scanner sc=new Scanner(System.in);
		s1.name=sc.nextLine();
		System.out.println("Enter mark1 and mark2: ");
		s1.mark1=sc.nextInt();
		s1.mark2=sc.nextInt();
		System.out.println("Total is: "+s1.computeTotal());
		System.out.println("Average is: "+s1.getAverage());
		System.out.println("Grade is: "+s1.determineGrade());
		
		Student s2=new Student();
		System.out.println("Enter student name: ");
		s2.name=sc.nextLine();
		System.out.println("Enter mark1 and mark2: ");
		s2.mark1=sc.nextInt();
		s2.mark2=sc.nextInt();
		System.out.println("Total is: "+s2.computeTotal());
		System.out.println("Average is: "+s2.getAverage());
		System.out.println("Grade is: "+s2.determineGrade());
	}

}
