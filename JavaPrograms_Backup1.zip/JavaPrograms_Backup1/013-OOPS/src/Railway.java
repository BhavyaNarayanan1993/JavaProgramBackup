
public class Railway {

	double ticketPrice;
	
	void calculatePrice(double amt,int count)
	{
		ticketPrice=amt*count;
	}
	
	void displayPrice() {
		System.out.println("TicketPrice :"+ticketPrice);
	}
}
