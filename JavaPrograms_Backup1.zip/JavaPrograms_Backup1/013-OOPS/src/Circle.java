
public class Circle {

	int radius;		//instance variable
	
	double computeArea()		//method
	{
		double PI=3.14;
		double area;
		area=PI*radius*radius;
		return area;
		
	}
}
