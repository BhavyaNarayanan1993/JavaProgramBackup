
public class SquareClient {

	public static void main(String[] args) {
		
		Square s1=new Square();
		s1.size=5;
		System.out.println("Size is :"+s1.size);
		System.out.println("Area is :"+s1.getArea());
		

		Square s2=new Square();
		s2.size=20;
		System.out.println("Size is :"+s2.size);
		System.out.println("Area is :"+s2.getArea());
		
		
		Square s3=new Square();
		s3.size=50;
		System.out.println("Size is :"+s3.size);
		System.out.println("Area is :"+s3.getArea());

	}

}
