import java.util.Scanner;

public class RailwayClient {

	public static void main(String[] args) {
		
		double price;
		int numberoftickets;
		Railway rail=new Railway();
		System.out.println("Enter the price of tickets: ");
		Scanner sc=new Scanner(System.in);
		price=sc.nextDouble();
		System.out.println("Enter the number of tickets: ");
		numberoftickets=sc.nextInt();
		
		rail.calculatePrice(price,numberoftickets);

		rail.displayPrice();
		
		Railway rail2=new Railway();
		System.out.println("Enter the price of tickets: ");
		price=sc.nextDouble();
		System.out.println("Enter the number of tickets: ");
		numberoftickets=sc.nextInt();
		
		rail2.calculatePrice(price,numberoftickets);

		rail2.displayPrice();
	}

}
