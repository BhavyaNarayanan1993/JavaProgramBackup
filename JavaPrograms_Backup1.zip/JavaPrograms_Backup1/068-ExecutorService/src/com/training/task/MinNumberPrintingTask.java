package com.training.task;

import java.util.concurrent.Callable;

public class MinNumberPrintingTask implements Callable<Double> {

	@Override
	public Double call() throws Exception {
		double[] darr = { 20.0, 30.0, 10.0, 50.0, 60.0 };
		double min = darr[0];
		for (int i = 0; i < darr.length; i++) {
			if (min > darr[i]) {
				min = darr[i];
			}
			Thread.sleep(1000);
			String tname = Thread.currentThread().getName();
			System.out.println(tname + " : " + min);
		}
		return min;
	}

}
