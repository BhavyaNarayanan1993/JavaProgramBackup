package com.training.task;

import java.util.concurrent.Callable;

public class MaxNumberPrintingTask implements Callable<Double> {

	@Override
	public Double call() throws Exception {
		double[] darr = { 20.0, 30.0, 70.0, 50.0, 60.0 };
		double max = darr[0];
		for (int i = 0; i < darr.length; i++) {
			if (max < darr[i]) {
				max = darr[i];
			}
			Thread.sleep(1000);
			String tname = Thread.currentThread().getName();
			System.out.println(tname + " : " + max);
		}
		return max;
	}
}
