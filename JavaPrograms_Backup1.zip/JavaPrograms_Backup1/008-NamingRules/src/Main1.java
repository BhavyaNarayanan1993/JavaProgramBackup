
public class Main1 {

	public static void main(String[] args) {
		int \u006110;
		a10=100;
		System.out.println(a10);
	}

}
