
public class A {
		int x;  	//instance variable
		static int y;		//static variable
		
		void printX() {
			System.out.println(this.x);
			this.printWelcome();
			System.out.println(y);
			printGoodBye();
			new A();
		}
		
		void printWelcome() {
			System.out.println("Welcome");
		}
		
		static void printY()
		{
			//System.out.println(x);
			//printWelcome();
			System.out.println(y);
			printGoodBye();
			new A();  //object is created  
			//System.out.println(this.x);
		}
		
		static void printGoodBye() {
			System.out.println("Goodbye");
		}
		A(){
			this(10); //should be the first statement
			System.out.println("A object created");
			System.out.println(this.x);
			printWelcome();
			System.out.println(y);
			printGoodBye();
			
		}
		A(int x){
			
			System.out.println("A object created with"+x);
			this.x=x;
		}
		
}
