package pack2;

import pack1.Circle;
import pack1.Employee;
import pack1.Manager;
import pack1.SalesEmployee;

public class Main2 {

	public static void main(String[] args) {
		
		byte b=90;
		int i=b;
		
		
		//Employee e;
		
		Object obj;
		obj=new Employee();//Reference casting, upcasting, implicit
		
		obj=new Manager();//Reference casting, upcasting, implicit
		
		obj=new SalesEmployee();//Reference casting, upcasting, implicit
		
		obj=new Circle();//Reference casting, upcasting, implicit
		

	}

}
