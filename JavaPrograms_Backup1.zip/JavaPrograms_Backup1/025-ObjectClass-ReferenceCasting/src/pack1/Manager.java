package pack1;

public class Manager extends Employee{
		
			int epmCount;

			public Manager(int id, String name, double basic, int epmCount) {
				super(id, name, basic);
				this.epmCount = epmCount;
			}

			public Manager() {
				super();
			}

			public int getEpmCount() {
				return epmCount;
			}

			public void setEpmCount(int epmCount) {
				this.epmCount = epmCount;
			}

			
			
			
			

}
