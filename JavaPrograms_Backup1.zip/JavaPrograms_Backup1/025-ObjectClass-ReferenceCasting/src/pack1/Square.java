package pack1;

public class Square {
	
	public int size;

	public int getSize() {
		return size;
	}

	public void setSize(int size) {
		this.size = size;
	}

	public Square(int size) {
		super();
		this.size = size;
	}

	public Square() {
		super();
	}
	
	public int getArea() {
		return this.size*this.size;
	}
	

}
