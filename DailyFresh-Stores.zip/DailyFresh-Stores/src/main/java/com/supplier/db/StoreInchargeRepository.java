package com.supplier.db;

import org.springframework.data.jpa.repository.JpaRepository;

import com.supplier.model.StoreIncharge;

public interface StoreInchargeRepository extends JpaRepository<StoreIncharge, Integer>{

}
