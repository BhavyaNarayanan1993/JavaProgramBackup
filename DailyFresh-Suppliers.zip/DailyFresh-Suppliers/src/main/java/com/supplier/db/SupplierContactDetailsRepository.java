package com.supplier.db;

import org.springframework.data.jpa.repository.JpaRepository;

import com.supplier.model.SupplierContactDetails;

public interface SupplierContactDetailsRepository extends JpaRepository<SupplierContactDetails, Integer>{

}
