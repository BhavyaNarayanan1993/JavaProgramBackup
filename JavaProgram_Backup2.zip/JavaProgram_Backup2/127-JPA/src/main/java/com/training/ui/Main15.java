package com.training.ui;

import java.util.List;
import java.util.Objects;

import com.training.model.Doctor;
import com.training.model.Loan;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import jakarta.persistence.Query;

public class Main15 {
	
	private static void test1() {
		Loan loan1=new Loan("Manu", 10000.0, 12);
		Loan loan2=new Loan("Surya", 8000.0, 14);
		Loan loan3=new Loan("Rohit", 6700.0, 20);
		Loan loan4=new Loan("Ankit", 5500.0, 26);
		Loan loan5=new Loan("Meenu", 13000.0, 16);
		
		EntityManagerFactory emf =Persistence.createEntityManagerFactory("PU");
		EntityManager em=emf.createEntityManager();
		
		em.getTransaction().begin();
		
		em.persist(loan1);
		em.persist(loan2);
		em.persist(loan3);
		em.persist(loan4);
		em.persist(loan5);
		
		em.getTransaction().commit();
		
		em.close();
		emf.close();
	}
	 //test nativequeries
	public static void test2() {
		
		
		
		EntityManagerFactory emf =Persistence.createEntityManagerFactory("PU");
		EntityManager em=emf.createEntityManager();
		
		String nsql="select * from loans";
		Query query=em.createNativeQuery(nsql);
		List<Object[]> results=query.getResultList();
		for (Object[] cols : results) {
			for (Object obj : cols) {
				System.out.print(obj+"\t\t");
			}
			System.out.println();
		}
		em.close();
		emf.close();
	}
	
	public static void test3() {
		EntityManagerFactory emf =Persistence.createEntityManagerFactory("PU");
		EntityManager em=emf.createEntityManager();
		
		String nsql="select * from loans";
		Query query=em.createNativeQuery(nsql, Loan.class);
		List<Loan> results=query.getResultList();
		
		System.out.println(results);
		em.close();
		emf.close();
				
	}
	
	//NAmedQueries
	private static void test4() {
		EntityManagerFactory emf =Persistence.createEntityManagerFactory("PU");
		EntityManager em=emf.createEntityManager();
		
		Query query= em.createNamedQuery("findAllLoans");
		List<Loan> allLoans=query.getResultList();
		System.out.println(allLoans);
		
		em.close();
		emf.close();
	}
	
	private static void test5() {
		EntityManagerFactory emf =Persistence.createEntityManagerFactory("PU");
		EntityManager em=emf.createEntityManager();
		
		Query query= em.createNamedQuery("findByLoanId");
		query.setParameter("searchLoanId", 2);
		Loan loan=(Loan)query.getSingleResult();
		System.out.println(loan);
		
		em.close();
		emf.close();
	}
	
	public static void test6() {
		EntityManagerFactory emf =Persistence.createEntityManagerFactory("PU");
		EntityManager em=emf.createEntityManager();
		
		Query query= em.createNamedQuery("updateLoanAmount");
		em.getTransaction().begin();
		int r=query.executeUpdate();
		em.getTransaction().commit();
		System.out.println(r+ " Records updated");
		em.close();
		emf.close();
	}
	
	public static void test7() {
		EntityManagerFactory emf =Persistence.createEntityManagerFactory("PU");
		EntityManager em=emf.createEntityManager();
		
		Query query= em.createNamedQuery("deleteBasedOnLoanAmount");
		query.setParameter("amountCutOff", 10000);
		em.getTransaction().begin();
		int r=query.executeUpdate();
		em.getTransaction().commit();
		System.out.println(r+ " Records deleted");
		em.close();
		emf.close();
	}
	
	public static void test8() {
		String qry="select l.customerName, l.loanAmount from Loan l";
		
		EntityManagerFactory emf =Persistence.createEntityManagerFactory("PU");
		EntityManager em=emf.createEntityManager();
		
		Query query=em.createQuery(qry);
		List<Objects[]> results=query.getResultList();
		
		for(Object[] cols:results) {
			System.out.println(cols[0]+"\t\t"+cols[1]);
		}
		
		em.close();
		emf.close();
	}
	
	public static void main(String[] args) {
		//test1();
		//test2();
		//test3();
		//test4();
		//test5();
		//test6();
		//test7();
		test8();
	}
}
