package com.training.ui;

import java.util.List;

import com.training.model.Doctor;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import jakarta.persistence.Query;

public class Main14 {

	public static void test1() {
		EntityManagerFactory emf =Persistence.createEntityManagerFactory("PU");
		EntityManager em=emf.createEntityManager();
		
		String nsql="select * from doctors";
		Query query=em.createNativeQuery(nsql);
		List<Object[]> results=query.getResultList();
		for (Object[] cols : results) {
			for (Object obj : cols) {
				System.out.print(obj+"\t\t");
			}
			System.out.println();
		}
		em.close();
		emf.close();
				
	}
	public static void test2() {
		EntityManagerFactory emf =Persistence.createEntityManagerFactory("PU");
		EntityManager em=emf.createEntityManager();
		
		String nsql="select * from doctors";
		Query query=em.createNativeQuery(nsql, Doctor.class);
		List<Doctor> results=query.getResultList();
		
		System.out.println(results);
		em.close();
		emf.close();
				
	}
	
	public static void main(String[] args) {
		//test1();
		test2();

	}

}
