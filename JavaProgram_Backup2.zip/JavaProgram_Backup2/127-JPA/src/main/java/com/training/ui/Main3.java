package com.training.ui;

import java.util.List;

import com.training.model.Candidate;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import jakarta.persistence.Query;

public class Main3 {

	private static void insert() {
		EntityManagerFactory emf =Persistence.createEntityManagerFactory("PU");
		EntityManager em=emf.createEntityManager();
		
		Candidate candidate=new Candidate("Divya", "Mangalore", new double[] {88.0,98.0,87.0});
		em.getTransaction().begin();
		em.persist(candidate);
		em.getTransaction().commit();
		
		em.close();
		emf.close();
	}
	
	private static void read() {
		EntityManagerFactory emf =Persistence.createEntityManagerFactory("PU");
		EntityManager em=emf.createEntityManager();
		
		Candidate candidate=em.find(Candidate.class, 1);
		System.out.println(candidate);
		
		em.close();
		emf.close();
	}
	
	private static void update() {
		EntityManagerFactory emf =Persistence.createEntityManagerFactory("PU");
		EntityManager em=emf.createEntityManager();
		
		Candidate candidate=em.find(Candidate.class, 1);
		candidate.setCity("Kolkatta");
		candidate.getMarks()[0]=25.0;
				
		em.getTransaction().begin();
		em.merge(candidate);
		em.getTransaction().commit();
		
		em.close();
		emf.close();
	}
	
	private static void readAll() {
		EntityManagerFactory emf =Persistence.createEntityManagerFactory("PU");
		EntityManager em=emf.createEntityManager();

		String qry="from Candidate ";
		Query query=em.createQuery(qry);
		List<Candidate> candidate= query.getResultList();
		System.out.println(candidate);
		
		em.close();
		emf.close();
	}
	
	private static void delete() {
		EntityManagerFactory emf =Persistence.createEntityManagerFactory("PU");
		EntityManager em=emf.createEntityManager();
		
		Candidate candidate=em.find(Candidate.class, 4);
				
		em.getTransaction().begin();
		em.remove(candidate);
		em.getTransaction().commit();
		
		em.close();
		emf.close();
	}
	
	public static void main(String[] args) {
		//insert();
		//read();
		//update();
		//readAll();
		delete();
	}

}
