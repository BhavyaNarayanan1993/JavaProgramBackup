package com.training.ui;

import java.util.List;

import com.training.model.Address;
import com.training.model.Employee;
import com.training.model.Question;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import jakarta.persistence.Query;

public class Main5 {

	private static void insert() {
		EntityManagerFactory emf =Persistence.createEntityManagerFactory("PU");
		EntityManager em=emf.createEntityManager();
		
		Address address=new Address("P-44", "Gandhi Nagar", "Madurai", "765765");
		Employee employee=new Employee("Sooraj", address, 22000.00);
		em.getTransaction().begin();
		em.persist(employee);
		em.getTransaction().commit();
		
		em.close();
		emf.close();
	}
	
	private static void read() {
		EntityManagerFactory emf =Persistence.createEntityManagerFactory("PU");
		EntityManager em=emf.createEntityManager();
		
		Employee employee=em.find(Employee.class, 2);
		System.out.println(employee);
		
		em.close();
		emf.close();
	}
	
	private static void update() {
		EntityManagerFactory emf =Persistence.createEntityManagerFactory("PU");
		EntityManager em=emf.createEntityManager();
		
		Employee employee=em.find(Employee.class, 2);
		employee.getAddress().setDoorNo("B-2");
		employee.getAddress().setCity("Delhi");
		employee.setBasicSalary(88880.00);
				
		em.getTransaction().begin();
		em.merge(employee);
		em.getTransaction().commit();
		
		em.close();
		emf.close();
	}
	
	private static void readAll() {
		EntityManagerFactory emf =Persistence.createEntityManagerFactory("PU");
		EntityManager em=emf.createEntityManager();

		String qry="from Employee ";
		Query query=em.createQuery(qry);
		List<Employee> employees= query.getResultList();
		System.out.println(employees);
		
		em.close();
		emf.close();
	}
	
	private static void delete() {
		EntityManagerFactory emf =Persistence.createEntityManagerFactory("PU");
		EntityManager em=emf.createEntityManager();
		
		Employee employee=em.find(Employee.class, 3);
				
		em.getTransaction().begin();
		em.remove(employee);
		em.getTransaction().commit();
		
		em.close();
		emf.close();
	}
	
	public static void main(String[] args) {
		//insert();
		//read();
		//update();
		//readAll();
		delete();
	}

}
