package com.training.ui;

import java.util.List;

import com.training.model.Bill;
import com.training.model.BillItem;
import com.training.model.Course;
import com.training.model.Subject;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import jakarta.persistence.Query;

public class Main10 {

	public static void insert() {
		EntityManagerFactory emf =Persistence.createEntityManagerFactory("PU");
		EntityManager em=emf.createEntityManager();
		
		Course course=new Course("Diploma in Web Technologies", 40000.00);
		Subject subject1=new Subject("HTML", 40);
		Subject subject2=new Subject("CSS", 20);
		Subject subject3=new Subject("Java Script", 25);
		Subject subject4=new Subject("React", 30);
		
		course.addSubject(subject1);
		course.addSubject(subject2);
		course.addSubject(subject3);
		course.addSubject(subject4);
		
		em.getTransaction().begin();
		em.persist(course);
		em.getTransaction().commit();
		
		em.close();
		emf.close();
	}
	
	public static void read() {
		EntityManagerFactory emf =Persistence.createEntityManagerFactory("PU");
		EntityManager em=emf.createEntityManager();
		
		Course course=em.find(Course.class, 0);
		System.out.println(course);
		
		em.close();
		emf.close();
	}
	public static void update() {		
		EntityManagerFactory emf =Persistence.createEntityManagerFactory("PU");
		EntityManager em=emf.createEntityManager();
		
		Course course=em.find(Course.class, 0);
		course.setFees(10000.0);
		course.getSubjects().add(new Subject("C Programming", 20));
		
		em.getTransaction().begin();
		em.merge(course);
		em.getTransaction().commit();
		
		em.close();
		emf.close();
	}
	
	private static void readAll() {
		EntityManagerFactory emf =Persistence.createEntityManagerFactory("PU");
		EntityManager em=emf.createEntityManager();

		String qry="from Bill ";
		Query query=em.createQuery(qry);
		List<Course> courses= query.getResultList();
		System.out.println(courses);
		
		em.close();
		emf.close();
	}
	
	private static void delete() {
		EntityManagerFactory emf =Persistence.createEntityManagerFactory("PU");
		EntityManager em=emf.createEntityManager();
		
		Course course=em.find(Course.class, 0);
				
		em.getTransaction().begin();
		em.remove(course);
		em.getTransaction().commit();
		
		em.close();
		emf.close();
	}
	public static void main(String[] args) {
		//insert();
		//read();
	//update();
	//readAll();
	//delete();
	
	}

}
