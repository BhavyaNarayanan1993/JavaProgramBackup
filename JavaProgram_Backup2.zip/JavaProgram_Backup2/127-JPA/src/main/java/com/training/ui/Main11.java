package com.training.ui;

import java.time.LocalDate;

import com.training.model.Doctor;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

public class Main11 {

	public static void main(String[] args) {
		Doctor doctor1=new Doctor("Santhosh", 500, "MALE", LocalDate.of(2006, 12, 15));
		Doctor doctor2=new Doctor("Abhi", 1000, "MALE", LocalDate.of(2004, 1, 25));
		Doctor doctor3=new Doctor("Sheela", 800, "FEMALE", LocalDate.of(2008, 4, 15));
		Doctor doctor4=new Doctor("Vikram", 600, "MALE", LocalDate.of(2002, 8, 5));
		Doctor doctor5=new Doctor("Ramesh", 850, "MALE", LocalDate.of(2006, 7, 7));

		EntityManagerFactory emf =Persistence.createEntityManagerFactory("PU");
		EntityManager em=emf.createEntityManager();
		
		em.getTransaction().begin();
		
		em.persist(doctor1);
		em.persist(doctor2);
		em.persist(doctor3);
		em.persist(doctor4);
		em.persist(doctor5);
		
		em.getTransaction().commit();
		
		em.clear();
		emf.close();
	}

}
