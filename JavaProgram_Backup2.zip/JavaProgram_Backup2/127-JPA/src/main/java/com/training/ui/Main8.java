package com.training.ui;

import java.time.LocalDate;
import java.util.List;

import com.training.model.Bill;
import com.training.model.BillItem;
import com.training.model.Category;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import jakarta.persistence.Query;

public class Main8 {

	public static void insert() {
		Bill bill=new Bill("Surya", LocalDate.of(2024, 12, 10));
		BillItem billItem1=new BillItem(1, "Nokia", 7, 79000.00);
		BillItem billItem2=new BillItem(2, "Lenovo", 3, 80000.00);
		BillItem billItem3=new BillItem(3, "Keyboard", 6, 5000.00);
		bill.addBillItem(billItem1);
		bill.addBillItem(billItem2);
		bill.addBillItem(billItem3);
		
		EntityManagerFactory emf =Persistence.createEntityManagerFactory("PU");
		EntityManager em=emf.createEntityManager();
		
		em.getTransaction().begin();
		em.persist(bill);
		em.getTransaction().commit();
		
		em.close();
		emf.close();
	}
	
	public static void update() {		
		EntityManagerFactory emf =Persistence.createEntityManagerFactory("PU");
		EntityManager em=emf.createEntityManager();
		
		Bill bill=em.find(Bill.class, 1);
		
		bill.removeBillItem(bill.getBillItems().get(2));
		bill.setCustomerName("Rahul");
		bill.addBillItem(new BillItem(5, "HeadPhones", 5, 1000.00));
		
		
		
		
		em.getTransaction().begin();
		em.merge(bill);
		em.getTransaction().commit();
		
		em.close();
		emf.close();
	}
	
	private static void read() {
		EntityManagerFactory emf =Persistence.createEntityManagerFactory("PU");
		EntityManager em=emf.createEntityManager();
		
		Bill bill=em.find(Bill.class, 1);
		System.out.println(bill);
		
		em.close();
		emf.close();
	}
	
	private static void readAll() {
		EntityManagerFactory emf =Persistence.createEntityManagerFactory("PU");
		EntityManager em=emf.createEntityManager();

		String qry="from Bill ";
		Query query=em.createQuery(qry);
		List<Bill> bills= query.getResultList();
		System.out.println(bills);
		
		em.close();
		emf.close();
	}
	
	private static void delete() {
		EntityManagerFactory emf =Persistence.createEntityManagerFactory("PU");
		EntityManager em=emf.createEntityManager();
		
		Bill bill=em.find(Bill.class, 4);
				
		em.getTransaction().begin();
		em.remove(bill);
		em.getTransaction().commit();
		
		em.close();
		emf.close();
	}
	
	public static void main(String[] args) {
		//insert();
		//update();
		//read();
		//readAll();
		delete();

	}

}
