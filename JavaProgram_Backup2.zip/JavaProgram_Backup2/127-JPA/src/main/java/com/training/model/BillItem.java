package com.training.model;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;

@Embeddable
public class BillItem {
		@Column
		int slno;
		
		@Column
		String itemName;
		
		@Column
		int quantity;
		
		@Column
		double price;

		public BillItem(int slno, String itemName, int quantity, double price) {
			super();
			this.slno = slno;
			this.itemName = itemName;
			this.quantity = quantity;
			this.price = price;
		}

		public BillItem() {
			super();
		}

		@Override
		public String toString() {
			return "\nBillItem [slno=" + slno + ", itemName=" + itemName + ", quantity=" + quantity + ", price=" + price
					+ "]";
		}

		
		
		
}
