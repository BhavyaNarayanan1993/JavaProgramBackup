package com.training.ui;

import java.util.List;

import com.training.model.Question;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import jakarta.persistence.Query;

public class Main4 {

	private static void insert() {
		EntityManagerFactory emf =Persistence.createEntityManagerFactory("PU");
		EntityManager em=emf.createEntityManager();
		
		String[] choices= {"true","false"};
		Question question=new Question("Java is OOPs?", 3, choices);
		
		em.getTransaction().begin();
		em.persist(question);
		em.getTransaction().commit();
		
		em.close();
		emf.close();
	}
	
	private static void read() {
		EntityManagerFactory emf =Persistence.createEntityManagerFactory("PU");
		EntityManager em=emf.createEntityManager();
		
		Question question=em.find(Question.class, 1);
		System.out.println(question);
		
		em.close();
		emf.close();
	}
	
	private static void update() {
		EntityManagerFactory emf =Persistence.createEntityManagerFactory("PU");
		EntityManager em=emf.createEntityManager();
		
		Question question=em.find(Question.class, 2);
		question.setQuestionText("Java supports Inheritance?");
		question.setMark(10);
				
		em.getTransaction().begin();
		em.merge(question);
		em.getTransaction().commit();
		
		em.close();
		emf.close();
	}
	
	private static void readAll() {
		EntityManagerFactory emf =Persistence.createEntityManagerFactory("PU");
		EntityManager em=emf.createEntityManager();

		String qry="from Question ";
		Query query=em.createQuery(qry);
		List<Question> questions= query.getResultList();
		System.out.println(questions);
		
		em.close();
		emf.close();
	}
	
	private static void delete() {
		EntityManagerFactory emf =Persistence.createEntityManagerFactory("PU");
		EntityManager em=emf.createEntityManager();
		
		Question question=em.find(Question.class, 4);
				
		em.getTransaction().begin();
		em.remove(question);
		em.getTransaction().commit();
		
		em.close();
		emf.close();
	}
	
	public static void main(String[] args) {
		//insert();
		//read();
		//update();
		//readAll();
		delete();

	}

}
