package com.training.ui;

import java.util.List;

import com.training.model.Player;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import jakarta.persistence.Query;

public class Main2 {

	public static void insertPlayer() {
		Player player=new Player(103, "Jadeja", "Cricketer", 34, 8);
		
		EntityManagerFactory emf =Persistence.createEntityManagerFactory("PU");
		EntityManager em=emf.createEntityManager();
		em.getTransaction().begin();
		em.persist(player);
		em.getTransaction().commit();
		
		em.close();
		emf.close();
	}
	
	public static void readPlayer() {
		EntityManagerFactory emf =Persistence.createEntityManagerFactory("PU");
		EntityManager em=emf.createEntityManager();
		
		Player player=em.find(Player.class, 100);
		System.out.println(player);
		
		em.close();
		emf.close();
	}
	
	public static void updatePlayer() {
		EntityManagerFactory emf =Persistence.createEntityManagerFactory("PU");
		EntityManager em=emf.createEntityManager();
		
		Player player=em.find(Player.class, 102);
		player.setTypeOfPlayer("Bowler");
		em.getTransaction().begin();
		em.merge(player);
		em.getTransaction().commit();
		
		em.close();
		emf.close();
	}
	
	public static void readAllPlayer() {
		EntityManagerFactory emf =Persistence.createEntityManagerFactory("PU");
		EntityManager em=emf.createEntityManager();
		
		String qry="from Player ";//Java Persistence Query Language
		Query query=em.createQuery(qry);
		List<Player> players= query.getResultList();
		System.out.println(players);
		em.close();
		emf.close();
	}
	
	public static void deletePlayer() {
		EntityManagerFactory emf =Persistence.createEntityManagerFactory("PU");
		EntityManager em=emf.createEntityManager();
		
		Player player=em.find(Player.class, 101);
		em.getTransaction().begin();
		em.remove(player);
		em.getTransaction().commit();
		
		em.close();
		emf.close();
	}
	
	public static void main(String[] args) {
		//insertPlayer();
		//readPlayer();
		//updatePlayer();
		//readAllPlayer();
		deletePlayer();

	}

}
