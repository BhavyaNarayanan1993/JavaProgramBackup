package com.training.ui;

import java.util.List;

import com.training.model.Doctor;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import jakarta.persistence.Query;

public class Main12 {
	
	private static void test1() {
		EntityManagerFactory emf =Persistence.createEntityManagerFactory("PU");
		EntityManager em=emf.createEntityManager();
		
		Query query= em.createNamedQuery("findAll");
		List<Doctor> allDoctors=query.getResultList();
		System.out.println(allDoctors);
		
		em.close();
		emf.close();
	}
	
	private static void test2() {
		EntityManagerFactory emf =Persistence.createEntityManagerFactory("PU");
		EntityManager em=emf.createEntityManager();
		
		Query query= em.createNamedQuery("findById");
		query.setParameter("searchId", 3);
		Doctor doctor=(Doctor) query.getSingleResult();
		System.out.println(doctor);
		
		em.close();
		emf.close();
	}
	
	public static void test3() {
		EntityManagerFactory emf =Persistence.createEntityManagerFactory("PU");
		EntityManager em=emf.createEntityManager();
		
		Query query= em.createNamedQuery("updateFees");
		em.getTransaction().begin();
		int r=query.executeUpdate();
		em.getTransaction().commit();
		System.out.println(r+ " Records updated");
		em.close();
		emf.close();
	}
	
	public static void test4() {
		EntityManagerFactory emf =Persistence.createEntityManagerFactory("PU");
		EntityManager em=emf.createEntityManager();
		
		Query query= em.createNamedQuery("deleteBasedOnFees");
		query.setParameter("feesCutOff", 1200);
		em.getTransaction().begin();
		int r=query.executeUpdate();
		em.getTransaction().commit();
		System.out.println(r+ " Records deleted");
		em.close();
		emf.close();
	}
	public static void main(String[] args) {
		//test1();
		//test2();
		//test3();
		test4();
	}

}
