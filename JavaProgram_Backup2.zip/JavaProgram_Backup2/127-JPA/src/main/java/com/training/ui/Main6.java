package com.training.ui;

import java.util.List;

import com.training.model.Book;
import com.training.model.Employee;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import jakarta.persistence.Query;

public class Main6 {

	
	public static void insert() {
		Book book=new Book("C", "Guruswamy");
		book.addTopic("C Introduction");
		book.addTopic("Datatypes");
		book.addTopic("Pointers");
		book.addTopic("Memory Allocation");
		
		EntityManagerFactory emf =Persistence.createEntityManagerFactory("PU");
		EntityManager em=emf.createEntityManager();
		
		em.getTransaction().begin();
		em.persist(book);
		em.getTransaction().commit();
		
		em.close();
		emf.close();
	}
	
	private static void read() {
		EntityManagerFactory emf =Persistence.createEntityManagerFactory("PU");
		EntityManager em=emf.createEntityManager();
		
		Book book=em.find(Book.class, 1);
		System.out.println(book);
		
		em.close();
		emf.close();
	}
	
	private static void update() {
		EntityManagerFactory emf =Persistence.createEntityManagerFactory("PU");
		EntityManager em=emf.createEntityManager();
		
		Book book=em.find(Book.class, 1);
		book.getTopics().add("Stream API");
				
		em.getTransaction().begin();
		em.merge(book);
		em.getTransaction().commit();
		
		em.close();
		emf.close();
	}
	
	private static void readAll() {
		EntityManagerFactory emf =Persistence.createEntityManagerFactory("PU");
		EntityManager em=emf.createEntityManager();

		String qry="from Book ";
		Query query=em.createQuery(qry);
		List<Book> books= query.getResultList();
		System.out.println(books);
		
		em.close();
		emf.close();
	}
	
	private static void delete() {
		EntityManagerFactory emf =Persistence.createEntityManagerFactory("PU");
		EntityManager em=emf.createEntityManager();
		
		Book book=em.find(Book.class, 2);
				
		em.getTransaction().begin();
		em.remove(book);
		em.getTransaction().commit();
		
		em.close();
		emf.close();
	}
	
	public static void main(String[] args) {
		insert();
		//read();
		//update();
		//readAll();
		//delete();
	}

}
