package com.training.actions;

import com.training.model.Customer;
import com.training.service.CustomerService;
import com.training.service.CustomerServiceImpl;
import com.training.ui.util.ConsoleIO;

public class UpdateAction extends Action{

	boolean status;
	@Override
	public void init() {
		System.out.println("\n\n");
		System.out.println("\t\t Updating Customer");
		System.out.println("\t\t------------------------");
		
	}

	@Override
	public void execute() {
		System.out.println("\t\tUpdating a Customer");
		int id;
		String name;
		double balance;
		String email;
		String phone;
		
		ConsoleIO.prompt("Enter Customer ID: ");
		id=ConsoleIO.intInput();
		try {
			if(id<0) {
				throw new Exception();
			}
				
		} catch (Exception e) {
			System.err.println("\t\tID cannot be Negative");
			ConsoleIO.prompt("Enter Customer ID: ");
			id=ConsoleIO.intInput();
		}
		ConsoleIO.prompt("Enter Name: ");
		name=ConsoleIO.stringInput();
		try {
			if(name.isEmpty() || name.equals(null)) {
				throw new Exception();
			}
				
		} catch (Exception e) {
			System.err.println("\t\tName cannot be empty");
			ConsoleIO.prompt("Enter Name: ");
			name=ConsoleIO.stringInput();
		}
	
		ConsoleIO.prompt("Enter Balance: ");
		balance=ConsoleIO.doubleInput();
		try {
			if(balance<0) {
				throw new Exception();
			}
				
		} catch (Exception e) {
			System.err.println("\t\tBalance cannot be Negative");
			ConsoleIO.prompt("Enter Balance: ");
			balance=ConsoleIO.doubleInput();
		}
		ConsoleIO.prompt("Enter Email: ");
		email=ConsoleIO.stringInput();
		try {
			if(email.isEmpty() || email.equals(null)) {
				throw new Exception();
			}
				
		} catch (Exception e) {
			System.err.println("\t\tInvalid Email");
			ConsoleIO.prompt("Enter Email: ");
			email=ConsoleIO.stringInput();
		}
		ConsoleIO.prompt("Enter Phone number: ");
		phone=ConsoleIO.stringInput();
		try {
			if(phone.isEmpty() || phone.equals(null)) {
				throw new Exception();
			}
				
		} catch (Exception e) {
			System.err.println("\t\tInvalid Phone");
			ConsoleIO.prompt("Enter Phone number: ");
			phone=ConsoleIO.stringInput();
		}
		
		Customer customer=new Customer(id, name, balance, email, phone);
		CustomerService service=new CustomerServiceImpl();
		status=service.updateCustomer(customer);
		
	}

	@Override
	public void complete() {
		System.out.println("\n\n");
		if(status==true)
			System.out.println("\t\tUpdating Student completed");
		else
			System.out.println("\t\tUpdating failed");
		System.out.println("\t\t------------------------");
		
	}

}
