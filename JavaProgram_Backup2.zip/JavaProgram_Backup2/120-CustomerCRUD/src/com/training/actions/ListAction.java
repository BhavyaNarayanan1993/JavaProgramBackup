package com.training.actions;

import java.util.List;

import com.training.model.Customer;

import com.training.service.CustomerService;
import com.training.service.CustomerServiceImpl;

public class ListAction extends Action {
	@Override
	public void init() {
		System.out.println("\n\n");
		System.out.println("\t\t Listing Student");
		System.out.println("\t\t------------------------");
		
	}

	@Override
	public void execute() {
		
		System.out.println("\t\tListing a student");
		CustomerService service= new CustomerServiceImpl();
		List<Customer> customerList=service.getAllCustomers();
		if(customerList==null || customerList.isEmpty()) {
			System.out.println("\n\n\t\t No Customer Found !!!");
		}
		else {
			System.out.println("\t\t ID \t\t Name \t\t\t Balance \t Email \t\t\t Phone \n");
			customerList.stream().forEach((c)->{
				System.out.printf("\t\t %d \t\t %-20s  %10.2f \t %-20s \t %-20s \n",
						c.getId(),
						c.getName(),
						c.getBalance(),
						c.getEmail(),
						c.getPhone()
						);
			});
			
		}
		
	}

	@Override
	public void complete() {
		System.out.println("\n\n");
		System.out.println("\t\tListing Customer completed");
		System.out.println("\t\t------------------------");
	}

}
