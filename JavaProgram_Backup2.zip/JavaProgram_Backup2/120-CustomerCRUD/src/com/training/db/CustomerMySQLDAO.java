package com.training.db;

import java.sql.Connection;
import java.util.List;

import com.training.model.Customer;


public interface CustomerMySQLDAO {

	String INSERT_QRY = "insert into customerstable values(?,?,?,?,?)";
	String UPDATE_QRY = "update customerstable set name=?, balance=?, email=? , phone=? where id=?";
	String DELETE_QRY = "delete from customerstable where id=?";
	String SEARCH_QRY = "select * from customerstable where id=?";
	String FINDALL_QRY = "select * from customerstable";

	boolean insertCustomer(Connection connection, Customer customer);

	boolean updateCustomer(Connection connection, Customer customer);

	boolean deleteCustomer(Connection connection, Customer customer);
	
	Customer findCustomerByID(Connection connection, int id);
	
	List<Customer> findAllCustomers(Connection connection);
}
