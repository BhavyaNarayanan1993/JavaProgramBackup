package com.training.ui;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class Main1 {

	public static void main(String[] args) {
		// Step 1
		// Load a Driver
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			System.out.println("Drive loaded Successfuly");
		} catch (ClassNotFoundException e) {
			System.err.println(e);
		}

		// Step 2
		// Establish a connection to a database
		Connection connection = null;
		String dburl = "jdbc:mysql://localhost:3306/trainingdb1?useSSL=false";
		String userName = "root";
		String password = "root";

		try {
			connection = DriverManager.getConnection(dburl, userName, password);
			System.out.println("Connected to Database");
		} catch (SQLException e) {
			e.printStackTrace();
		}

		// Step3
		// calling stored procedures
		try {
			CallableStatement statement=connection.prepareCall("{call countrycount(?,?)}");
			statement.setString(1, "India");
			statement.registerOutParameter(2, java.sql.Types.INTEGER);
			statement.execute();
			System.out.println(statement.getInt(2));
		} catch (SQLException e1) {
			System.err.println(e1);
		}
		
		
		// Step 4
		// Close the connection
		try {
			connection.close();
			System.out.println("Connection to Database");
		} catch (SQLException e) {
			System.err.println(e);

		}

	}

}
