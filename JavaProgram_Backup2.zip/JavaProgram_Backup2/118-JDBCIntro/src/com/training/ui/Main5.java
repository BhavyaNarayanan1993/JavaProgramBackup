package com.training.ui;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Main5 {

	public static void main(String[] args) {
		// Step 1
		// Load a Driver
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			System.out.println("Drive loaded Successfuly");
		} catch (ClassNotFoundException e) {
			System.err.println(e);
		}

		// Step 2
		// Establish a connection to a database
		Connection connection = null;
		String dburl = "jdbc:mysql://localhost:3306/trainingdb1?useSSL=false";
		String userName = "root";
		String password = "root";

		try {
			connection = DriverManager.getConnection(dburl, userName, password);
			System.out.println("Connected to Database");
		} catch (SQLException e) {
			e.printStackTrace();
		}

		// Step3
		// Execute Queries
		String query = "Select * from Products where pid=1001";
		try {
			Statement statement = connection.createStatement();
			ResultSet rs = statement.executeQuery(query);
			if (rs.next()) {
				int pid = rs.getInt(1);
				String pname = rs.getString(2);
				double price = rs.getDouble(3);
				String category = rs.getString(4);
				System.out.printf("%d %-20s %10.2f %-20s \n", pid, pname, price, category);
			} else {
				System.out.println("Record not Found!!!");
			}
			rs.close();
		} catch (SQLException e) {

			e.printStackTrace();
		}

		// Step 4
		// Close the connection
		try {
			connection.close();
			System.out.println("Connection to Database");
		} catch (SQLException e) {
			System.err.println(e);

		}

	}

}
