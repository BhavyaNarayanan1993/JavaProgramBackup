package com.training.ui;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class Main6 {

	public static void main(String[] args) {
		// Step 1
		// Load a Driver
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			System.out.println("Drive loaded Successfuly");
		} catch (ClassNotFoundException e) {
			System.err.println(e);
		}

		// Step 2
		// Establish a connection to a database
		Connection connection = null;
		String dburl = "jdbc:mysql://localhost:3306/trainingdb1?useSSL=false";
		String userName = "root";
		String password = "root";

		try {
			connection = DriverManager.getConnection(dburl, userName, password);
			System.out.println("Connected to Database");
		} catch (SQLException e) {
			e.printStackTrace();
		}

		// Step3
		// Execute Queries
		String query = "insert into products values (?,?,?,?)";
		try {
			PreparedStatement statement = connection.prepareStatement(query);
			System.out.println("Statement Created Successfully");
			Scanner scanner = new Scanner(System.in);
			int pid;
			String pname;
			double price;
			String category;
			System.out.println("Enter Id : ");
			pid = Integer.parseInt(scanner.nextLine());

			System.out.println("Enter Name: ");
			pname = scanner.nextLine();

			System.out.println("Enter Price: ");
			price = Double.parseDouble(scanner.nextLine());

			System.out.println("Enter Category: ");
			category = scanner.nextLine();

			// fill the parameter
			statement.setInt(1, pid);
			statement.setString(2, pname);
			statement.setDouble(3, price);
			statement.setString(4, category);

			int r = statement.executeUpdate();
			System.out.println(r + "row(s) inserted");
			statement.close();
		} catch (SQLException e) {
			System.err.println(e);
		}

		// Step 4
		// Close the connection
		try {
			connection.close();
			System.out.println("Connection to Database");
		} catch (SQLException e) {
			System.err.println(e);

		}

	}

}
