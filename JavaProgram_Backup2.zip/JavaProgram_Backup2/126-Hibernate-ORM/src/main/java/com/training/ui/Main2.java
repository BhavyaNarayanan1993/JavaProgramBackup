package com.training.ui;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;

import com.training.model.Product;

public class Main2 {

	private static void insertProduct() {
		Product product = new Product(1003, "Iphone", 70000.0, "Phone");
		// save this to db
		SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
		Session session = sessionFactory.openSession();

		session.getTransaction().begin();
		session.persist(product);
		session.getTransaction().commit();

		session.close();
		sessionFactory.close();

	}

	private static void readProduct() {
		SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
		Session session = sessionFactory.openSession();

		Product product;
		product = session.find(Product.class, 1002);

		System.out.println(product);

		session.close();
		sessionFactory.close();

	}

	private static void updateProduct() {
		SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
		Session session = sessionFactory.openSession();

		Product product = session.find(Product.class, 1003);
		product.setName(product.getName().toUpperCase());

		session.getTransaction().begin();
		session.merge(product);
		session.getTransaction().commit();

		session.close();
		sessionFactory.close();
	}

	public static void readAllProduct() {
		SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
		Session session = sessionFactory.openSession();

		String str = "from Product";
		Query<Product> qry = session.createQuery(str, Product.class);

		List<Product> productList = qry.getResultList();
		System.out.println(productList);

		session.close();
		sessionFactory.close();

	}

	public static void deleteProduct() {
		SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
		Session session = sessionFactory.openSession();

		Product product = session.find(Product.class, 1001);

		session.getTransaction().begin();
		session.remove(product);
		session.getTransaction().commit();

		session.close();
		sessionFactory.close();

	}

	public static void main(String[] args) {
		// insertProduct();
		// readProduct();
		// updateProduct();
		readAllProduct();
		// deleteProduct();
	}

}
